(function () {
  'use strict';

  // Re-running (e.g. via bookmarklet) toggles the sheet instead of double-injecting.
  if (window.__assay) { try { window.__assay.toggle(); } catch (e) {} return; }

  var VERSION = '0.26.3';
  var MAP_KEY = 'assay.byConvo.v1';
  var BACKUP_MAP_KEY = 'assay.backupByConvo.v1';
  var LEGACY_KEY = 'deepdive.fragments.v1';
  var MIN_SEL_LEN = 4;
  // GitHub and Gist are a reading surface with no composer: the same tap
  // grammar over a file's rendered markdown or its code lines, and the
  // collected set is copied out rather than written into a message box. A
  // gist's classic table markup (<table class="js-file-line-container">,
  // one <td> per line, an empty <td class="blob-num"> beside it) already
  // matches the selectors github.com's newer blob view needed.
  var IS_GITHUB = location.hostname === 'github.com' || location.hostname === 'gist.github.com';
  var GH_CONTENT = '.markdown-body,.react-code-lines,table.js-file-line-container,.blob-wrapper';
  var GH_CODE = '.react-code-lines,table.js-file-line-container,.blob-wrapper';
  var READ_NOUN = IS_GITHUB ? 'file' : 'reply';
  var BRAND = location.hostname === 'claude.ai' ? 'Claude'
    : (IS_GITHUB ? 'File' : 'ChatGPT');

  // Rotating highlight colors: pending selection previews the color the next
  // fragment will get; collected marks stay on the page in the same hue.
  var PALETTE = [
    { rgb: '56,189,248', badgeBg: '#bae6fd', badgeInk: '#075985' },  // sky
    { rgb: '251,191,36', badgeBg: '#fde68a', badgeInk: '#92400e' },  // amber
    { rgb: '74,222,128', badgeBg: '#bbf7d0', badgeInk: '#166534' },  // green
    { rgb: '244,114,182', badgeBg: '#fbcfe8', badgeInk: '#9d174d' }, // pink
    { rgb: '167,139,250', badgeBg: '#ddd6fe', badgeInk: '#5b21b6' }, // violet
    { rgb: '251,146,60', badgeBg: '#fed7aa', badgeInk: '#9a3412' }   // orange
  ];
  function nextColorIdx() { return fragments.length % PALETTE.length; }
  // The verb palette: one tap classifies a passage instead of writing a note.
  // Each verb renders as a plain-English leading clause in the payload, so the
  // model needs no legend and the payload stays boilerplate-free.
  var VERBS = [
    { id: 'keep', label: 'Keep', clause: 'keep as is' },
    { id: 'push', label: 'Push', clause: 'push this further' },
    { id: 'tweak', label: 'Tweak', clause: 'tweak this, keep the idea' },
    { id: 'reword', label: 'Reword', clause: 'reword this' },
    { id: 'challenge', label: 'Challenge', clause: 'challenge this' },
    { id: 'cut', label: 'Cut', clause: 'drop this' }
  ];
  function verbById(id) {
    for (var i = 0; i < VERBS.length; i++) if (VERBS[i].id === id) return VERBS[i];
    return null;
  }

  function loadJSON(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch (e) { return fallback; }
  }
  // Each conversation keeps its own fragment list, keyed "<host>:<convo id>"
  // ("<host>:draft" before a brand-new chat gets its id — that batch follows
  // the chat once the id appears). A shared cross-conversation list can layer
  // on top of this keying later.
  function convoKey() {
    // Every file keeps its own list, the way every conversation does.
    if (IS_GITHUB) return location.hostname + ':' + location.pathname.replace(/\/+$/, '');
    var m = location.pathname.match(/\/(?:c|chat)\/([A-Za-z0-9-]+)/);
    return location.hostname + ':' + (m ? m[1] : 'draft');
  }
  function normalize(list) {
    list.forEach(function (f, i) {
      if (!f.notePos) f.notePos = 'post';
      if (typeof f.verb !== 'string') f.verb = '';
      if (f.verb === 'fix') f.verb = 'reword'; // 0.9.0's Fix split into Tweak / Reword
      if (typeof f.colorIdx !== 'number') f.colorIdx = i % PALETTE.length;
    });
    return list;
  }
  function saveMap(key, map) {
    try { localStorage.setItem(key, JSON.stringify(map)); } catch (e) {}
  }
  // Fragments collected under the earlier names (DeepDive/DigBoard, Winnow)
  // move to the assay.* keys once, so nothing already on the device is orphaned.
  [['deepdive.byConvo.v1', MAP_KEY], ['winnow.byConvo.v1', MAP_KEY],
   ['deepdive.backupByConvo.v1', BACKUP_MAP_KEY], ['winnow.backupByConvo.v1', BACKUP_MAP_KEY]]
    .forEach(function (pair) {
      try {
        var old = localStorage.getItem(pair[0]);
        if (!old) return;
        if (!localStorage.getItem(pair[1])) localStorage.setItem(pair[1], old);
        localStorage.removeItem(pair[0]);
      } catch (e) {}
    });

  var convo = convoKey();
  var byConvo = loadJSON(MAP_KEY, {});
  // One-time migration of the 0.3.x single global list into this conversation.
  var legacy = loadJSON(LEGACY_KEY, null);
  if (legacy && legacy.length) {
    byConvo[convo] = (byConvo[convo] || []).concat(legacy);
    saveMap(MAP_KEY, byConvo);
    try { localStorage.removeItem(LEGACY_KEY); } catch (e) {}
  }
  var fragments = normalize(byConvo[convo] || []);
  function persist() {
    var map = loadJSON(MAP_KEY, {});
    if (fragments.length) map[convo] = fragments; else delete map[convo];
    saveMap(MAP_KEY, map);
  }
  function loadBackup() {
    return loadJSON(BACKUP_MAP_KEY, {})[convo] || null;
  }
  function saveBackup() {
    var map = loadJSON(BACKUP_MAP_KEY, {});
    map[convo] = fragments;
    saveMap(BACKUP_MAP_KEY, map);
  }

  var sheetOpen = false;
  var pad = null;          // the scratchpad, bound once the shell exists

  // ---------------------------------------------------------------- UI shell
  var host = document.createElement('div');
  host.id = 'assay-host';
  host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483646;';
  // Key events from inside the shadow root reach the page retargeted to this
  // bare host div, so ChatGPT's "type anywhere to focus the composer" handler
  // doesn't see an editable target and steals focus mid-note. Marking the host
  // contenteditable makes those handlers treat our typing as already-editable.
  host.setAttribute('contenteditable', 'true');
  var root = host.attachShadow({ mode: 'open' });
  root.innerHTML =
    '<style>' +
    ':host{all:initial}' +
    '*{box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;-webkit-tap-highlight-color:transparent}' +
    'button{border:0;cursor:pointer;background:none;padding:0}' +
    '.hl{position:fixed;border-radius:3px;pointer-events:none;z-index:4}' +
    '.bar{position:fixed;display:none;flex-direction:column;align-items:flex-start;gap:2px;background:#111827;color:#f9fafb;' +
      'padding:5px 8px;border-radius:18px;box-shadow:0 4px 16px rgba(0,0,0,.35);z-index:10;user-select:none}' +
    '.bar.show{display:flex}' +
    '.bar button{color:#f9fafb;font-size:14px;font-weight:600;padding:6px 10px;border-radius:999px;touch-action:manipulation;white-space:nowrap}' +
    '.bar button:active{background:#374151}' +
    '.bar .x{color:#9ca3af}' +
    '.bar .drop{color:#fca5a5}' +
    '.bar .tag{flex:none;border-radius:999px;min-width:20px;height:20px;margin:0 4px 0 2px;' +
      'display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700}' +
    '.bar [hidden]{display:none}' +
    '.bar .row{display:flex;gap:2px;align-items:center}' +
    '.verbs{display:flex;gap:3px;flex-wrap:wrap}' +
    '.vb{background:#1f2937;color:#cbd5e1;font-size:12px;font-weight:600;border-radius:999px;padding:6px 8px;touch-action:manipulation;white-space:nowrap}' +
    '.vb:active,.vb.on{background:#38bdf8;color:#0c1220}' +
    '.notebox{position:fixed;display:none;flex-direction:column;gap:8px;background:#111827;color:#f9fafb;' +
      'padding:10px 12px;border-radius:14px;box-shadow:0 4px 18px rgba(0,0,0,.4);z-index:26;' +
      'width:min(480px,calc(100vw - 16px))}' +
    '.notebox.show{display:flex}' +
    '.notebox input,.notebox textarea{border:1px solid #374151;border-radius:8px;background:#1f2937;' +
      'color:#f9fafb;padding:9px 10px;font-size:15px;outline:none;font-family:inherit}' +
    '.notebox .row{display:flex;gap:8px;align-items:center}' +
    '.posbtn{background:#1f2937;color:#9ca3af;font-size:13px;font-weight:600;border-radius:999px;padding:7px 12px}' +
    '.posbtn.on{background:#38bdf8;color:#0c1220}' +
    '.notebox .add{margin-left:auto;background:#38bdf8;color:#0c1220;font-size:14px;font-weight:700;' +
      'border-radius:999px;padding:8px 16px}' +
    '.chip{position:fixed;display:none;align-items:center;gap:6px;background:#111827;color:#f9fafb;' +
      'padding:10px 16px;border-radius:999px;font-size:15px;font-weight:600;box-shadow:0 4px 16px rgba(0,0,0,.35);' +
      'z-index:10;user-select:none;touch-action:manipulation}' +
    '.chip.show{display:flex}' +
    '.pill{position:fixed;right:12px;bottom:110px;display:none;align-items:center;gap:8px;' +
      'background:#111827;color:#f9fafb;padding:12px 18px;border-radius:999px;font-size:15px;font-weight:600;' +
      'box-shadow:0 6px 20px rgba(0,0,0,.4);z-index:25;touch-action:none;cursor:grab}' +
    '.pill.show{display:flex}' +
    '.pill.dragging{cursor:grabbing;box-shadow:0 10px 28px rgba(0,0,0,.5)}' +
    // Compact: a 46px round badge — the count when there is one, an A otherwise.
    '.pill.compact{padding:0;width:46px;height:46px;justify-content:center;gap:0;font-size:17px}' +
    '.pill.compact .n{min-width:0;height:auto;background:transparent;color:#38bdf8;font-size:16px;padding:0}' +
    '.pill .n{background:#38bdf8;color:#0c1220;border-radius:999px;min-width:24px;height:24px;display:flex;' +
      'align-items:center;justify-content:center;font-size:13px;padding:0 6px}' +
    '.sheet{position:fixed;left:0;right:0;bottom:0;max-height:70vh;display:none;flex-direction:column;' +
      'background:#f8fafc;color:#0f172a;border-radius:18px 18px 0 0;box-shadow:0 -8px 30px rgba(0,0,0,.35);z-index:21}' +
    '.sheet.show{display:flex}' +
    '.sheet header{display:flex;align-items:center;justify-content:space-between;padding:14px 16px 8px}' +
    '.sheet header h2{margin:0;font-size:17px;font-weight:700}' +
    '.sheet header .close{font-size:22px;line-height:1;padding:4px 10px;color:#64748b}' +
    '.list{overflow-y:auto;padding:0 14px;flex:1;-webkit-overflow-scrolling:touch}' +
    '.frag{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:10px 12px;margin-bottom:10px}' +
    '.frag .top{display:flex;gap:10px;align-items:flex-start}' +
    '.frag .idx{flex:none;border-radius:999px;min-width:22px;height:22px;' +
      'display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;margin-top:1px}' +
    '.frag .txt{flex:1;font-size:14px;line-height:1.45;color:#1e293b;display:-webkit-box;-webkit-line-clamp:3;' +
      '-webkit-box-orient:vertical;overflow:hidden;white-space:pre-wrap}' +
    '.frag .txt.full{-webkit-line-clamp:unset}' +
    '.frag .del{flex:none;color:#94a3b8;font-size:18px;padding:2px 6px}' +
    '.frag .noterow{display:flex;gap:8px;margin-top:8px;align-items:center}' +
    '.frag input{flex:1;border:1px dashed #cbd5e1;border-radius:8px;padding:8px 10px;' +
      'font-size:14px;background:#f8fafc;color:#0f172a;outline:none;min-width:0}' +
    '.frag input:focus{border-color:#38bdf8;border-style:solid}' +
    '.frag .pos{flex:none;background:#e2e8f0;color:#475569;font-size:12px;font-weight:700;' +
      'border-radius:999px;padding:7px 10px;touch-action:manipulation}' +
    '.frag .pos.verb{background:#f1f5f9;color:#94a3b8}' +
    '.frag .pos.verb.on{background:#0284c7;color:#fff}' +
    '.sheet .hint{margin:0 16px 8px;font-size:12px;color:#64748b}' +
    '.picks{overflow-y:auto;padding:0 14px 4px;flex:1;-webkit-overflow-scrolling:touch}' +
    '.pick{display:flex;gap:8px;align-items:stretch;margin-bottom:8px}' +
    '.pick .row{flex:1;display:flex;gap:10px;align-items:flex-start;text-align:left;min-width:0;' +
      'background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:9px 11px;touch-action:manipulation}' +
    '.pick .row.on{border-color:#38bdf8;background:#f0f9ff}' +
    '.pick .tick{flex:none;width:20px;height:20px;border-radius:6px;border:1.5px solid #cbd5e1;color:transparent;' +
      'display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;margin-top:1px}' +
    '.pick .row.on .tick{background:#0284c7;border-color:#0284c7;color:#fff}' +
    '.pick .body{flex:1;min-width:0}' +
    '.pick .who{display:block;font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#64748b}' +
    '.pick .prev{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;' +
      'font-size:13px;line-height:1.4;color:#334155;margin-top:2px}' +
    '.pick .from{flex:none;width:38px;border-radius:12px;background:#e2e8f0;color:#475569;' +
      'font-size:15px;font-weight:700;touch-action:manipulation}' +
    '.pick .meta{display:block;margin-top:6px;padding:3px 8px;border-radius:999px;background:#f1f5f9;' +
      'color:#64748b;font-size:11px;font-weight:600;touch-action:manipulation}' +
    '.pick .meta.open{background:#0284c7;color:#fff}' +
    '.pick .full{margin:8px 0 0;padding:8px 10px;max-height:40vh;overflow:auto;background:#f8fafc;' +
      'border:1px solid #e2e8f0;border-radius:8px;font:12px/1.5 ui-monospace,monospace;color:#334155;' +
      'white-space:pre-wrap;word-break:break-word;-webkit-overflow-scrolling:touch}' +
    '.empty{padding:26px 10px;text-align:center;color:#64748b;font-size:14px;line-height:1.6}' +
    '.empty .restore{color:#0284c7;font-weight:600;text-decoration:underline;font-size:14px}' +
    '.actions{display:flex;gap:10px;padding:10px 14px 0}' +
    '.actions.last{padding-bottom:calc(14px + env(safe-area-inset-bottom))}' +
    '.btn{flex:1;border-radius:12px;padding:13px 10px;font-size:15px;font-weight:700;touch-action:manipulation}' +
    '.btn.minor{background:#e2e8f0;color:#475569;font-size:14px;padding:11px 8px}' +
    '.btn.go{background:#0284c7;color:#fff;padding:15px 10px}' +
    '.btn:disabled{opacity:.5}' +
    '.manual{margin:10px 14px 0;display:none}' +
    '.manual.show{display:block}' +
    '.manual textarea{width:100%;height:120px;border:1px solid #cbd5e1;border-radius:10px;padding:10px;font-size:13px;background:#fff;color:#0f172a}' +
    // Two strips that sit under the hint: one asks before the walk, one reports
    // during it. Neither is ever on screen at the same time as the other.
    '.strip{display:none;align-items:center;gap:8px;margin:0 16px 10px;padding:9px 11px;' +
      'border-radius:10px;font-size:12.5px;line-height:1.35}' +
    '.strip.show{display:flex}' +
    '.strip span{flex:1;min-width:0}' +
    '.strip .btn{flex:0 0 auto;padding:8px 11px;font-size:13px;border-radius:9px}' +
    '.strip.work{background:#1e293b;color:#e2e8f0}' +
    '.strip.ask{background:#fffbeb;color:#92400e;border:1px solid #fcd34d}' +
    // The walk moves the page about, so it is coloured like something that
    // does, and sized like the secondary action it is — never mistakable for
    // Download, which is the button you actually came here for.
    '.actions.aside{justify-content:flex-end;padding:0 16px 6px}' +
    '.actions.off{display:none}' +
    '.btn.warn{flex:0 0 auto;background:transparent;border:1px solid #d97706;color:#b45309;' +
      'font-size:13px;font-weight:600;padding:9px 12px;border-radius:10px}' +
    '.btn.minor.cog{flex:0 0 auto;padding:11px 13px;font-size:15px}' +
    // The note input grows while you dictate, because a line that scrolls away
    // as it is spoken is a line you cannot check.
    '.noterow{display:flex;gap:8px;align-items:flex-end}' +
    '#noteInput{flex:1;min-width:0;resize:none;max-height:38vh;overflow-y:auto;line-height:1.4}' +
    '#noteInput.tall{min-height:22vh}' +
    '.mic{flex:0 0 auto;width:44px;height:44px;border-radius:50%;background:#e2e8f0;color:#0f172a;font-size:18px}' +
    '.mic.on{background:#dc2626;color:#fff;animation:pulse 1.4s ease-in-out infinite}' +
    '@keyframes pulse{0%,100%{opacity:1}50%{opacity:.55}}' +
    '.interim{opacity:.55;font-style:italic}' +
    // Near-fullscreen: a scratchpad is a place you are working, not a strip.
    '.pad{position:fixed;left:0;right:0;top:0;bottom:0;display:none;flex-direction:column;' +
      'background:#fff;color:#0f172a;z-index:6}' +
    '.pad.show{display:flex}' +
    '.pad header{display:flex;align-items:center;justify-content:space-between;' +
      'padding:calc(10px + env(safe-area-inset-top)) 16px 8px}' +
    '.pad header h2{margin:0;font-size:17px;font-weight:700}' +
    '.pad header .close{font-size:22px;line-height:1;padding:4px 10px;color:#64748b}' +
    '.padwrap{flex:1;overflow-y:auto;padding:4px 16px 8px;-webkit-overflow-scrolling:touch}' +
    '.padtext{display:block;width:100%;min-height:100%;border:0;outline:none;resize:none;background:transparent;' +
      'color:inherit;font:inherit;font-size:17px;line-height:1.55;padding:0}' +
    '.padtext::placeholder{color:#94a3b8}' +
    '.padbar{display:none;gap:8px;padding:0 14px 8px}' +
    '.padbar.show{display:flex}' +
    '.padask{display:none;align-items:center;gap:8px;margin:0 16px 10px;padding:9px 11px;border-radius:10px;' +
      'font-size:12.5px;line-height:1.35;background:#fffbeb;color:#92400e;border:1px solid #fcd34d}' +
    '.padask.show{display:flex}' +
    '.padask span{flex:1;min-width:0}' +
    '.padask .btn{flex:0 0 auto;padding:8px 11px;font-size:13px}' +
    '.padfoot{display:flex;justify-content:center;padding:4px 14px 0}' +
    '.rec{display:flex;align-items:center;gap:10px;padding:13px 22px;border-radius:999px;' +
      'background:#0f172a;color:#f8fafc;font-size:15px;font-weight:700}' +
    '.rec .dot{width:11px;height:11px;border-radius:50%;background:#94a3b8}' +
    '.rec.on{background:#dc2626}' +
    '.rec.on .dot{background:#fff;animation:pulse 1.4s ease-in-out infinite}' +
    '.toast{position:fixed;left:50%;transform:translateX(-50%);bottom:60px;background:#111827;color:#f9fafb;' +
      'padding:10px 18px;border-radius:999px;font-size:14px;font-weight:600;box-shadow:0 4px 16px rgba(0,0,0,.35);' +
      'opacity:0;transition:opacity .25s;pointer-events:none;z-index:30;max-width:86vw;text-align:center}' +
    '.toast.show{opacity:1}' +
    '@media (prefers-color-scheme: dark){' +
      '.sheet{background:#0f172a;color:#e2e8f0}' +
      '.frag{background:#1e293b;border-color:#334155}' +
      '.frag .txt{color:#e2e8f0}' +
      '.frag input{background:#0f172a;border-color:#475569;color:#e2e8f0}' +
      '.frag .pos{background:#334155;color:#cbd5e1}' +
      '.frag .pos.verb{background:#1e293b;color:#64748b}' +
      '.frag .pos.verb.on{background:#38bdf8;color:#0c1220}' +
      '.btn.minor{background:#334155;color:#cbd5e1}' +
      '.btn.warn{border-color:#a16207;color:#fbbf24}' +
      '.strip.ask{background:#3a2c07;color:#fde68a;border-color:#854d0e}' +
      '.pad{background:#0b1220;color:#e2e8f0}' +
      '.padtext::placeholder{color:#64748b}' +
      '.mic{background:#334155;color:#e2e8f0}' +
      '.rec{background:#1e293b}' +
      '.padask{background:#3a2c07;color:#fde68a;border-color:#854d0e}' +
      '.empty{color:#94a3b8}' +
      '.manual textarea{background:#1e293b;border-color:#475569;color:#e2e8f0}' +
      '.pick .row{background:#1e293b;border-color:#334155}' +
      '.pick .row.on{background:#0c4a6e;border-color:#38bdf8}' +
      '.pick .prev{color:#cbd5e1}' +
      '.pick .from{background:#334155;color:#cbd5e1}' +
      '.pick .meta{background:#334155;color:#94a3b8}' +
      '.pick .meta.open{background:#38bdf8;color:#0c1220}' +
      '.pick .full{background:#0f172a;border-color:#334155;color:#cbd5e1}' +
      '.sheet .hint{color:#94a3b8}' +
    '}' +
    '</style>' +
    '<div id="hlLayer"></div>' +
    '<div class="bar" id="bar">' +
      '<div class="row">' +
        '<span class="tag" id="editTag" hidden></span>' +
        '<button id="addBtn">&#xFF0B; Add</button>' +
        '<button id="noteBtn">&#x270E; Note</button>' +
        '<button class="drop" id="removeBtn" hidden>Remove</button>' +
        '<button class="x" id="cancelBtn">&#x2715;</button>' +
      '</div>' +
      '<div class="verbs" id="barVerbs"></div>' +
    '</div>' +
    '<div class="notebox" id="notebox">' +
      '<div class="noterow">' +
        '<textarea id="noteInput" rows="1" placeholder="annotation &mdash; e.g. &ldquo;formalize this&rdquo;"></textarea>' +
        '<button class="mic" id="noteMic" title="Dictate">&#x1F3A4;</button>' +
      '</div>' +
      '<div class="verbs" id="noteVerbs"></div>' +
      '<div class="row">' +
        '<button class="posbtn" id="posPre">before</button>' +
        '<button class="posbtn on" id="posPost">after</button>' +
        '<button class="add" id="noteAdd">Add</button>' +
      '</div>' +
    '</div>' +
    '<button class="chip" id="chip">&#xFF0B; Collect</button>' +
    '<button class="pill" id="pill"><span id="pillLabel">Assay</span><span class="n" id="count">0</span></button>' +
    '<div class="sheet" id="sheet">' +
      '<header><h2>Collected fragments</h2><button class="close" id="closeBtn">&#x2715;</button></header>' +
      '<div class="list" id="list"></div>' +
      '<div class="manual" id="manual"><textarea id="manualTxt" readonly></textarea></div>' +
      '<div class="actions">' +
        '<button class="btn minor" id="clearBtn">Clear</button>' +
        '<button class="btn minor" id="mdBtn">&#x2B07; .md</button>' +
        '<button class="btn minor" id="txtBtn">&#x2B07; .txt</button>' +
        '<button class="btn minor cog" id="cogBtn" title="Settings">&#x2699;</button>' +
      '</div>' +
      '<div class="actions">' +
        '<button class="btn minor" id="padBtn">&#x1F3A4; Voice scratchpad</button>' +
      '</div>' +
      '<div class="actions actions-settings off" id="settingsRow">' +
        '<button class="btn minor" id="flatBtn" title="Read cards the site made editable as ordinary text">Cards: text</button>' +
        '<button class="btn minor" id="compactBtn" title="A small round button instead of the Assay pill">Button: full</button>' +
        '<button class="btn minor" id="diagBtn" title="Copy what Assay can see on this page">&#x24D8; Copy diagnosis</button>' +
      '</div>' +
      '<div class="actions last">' +
        '<button class="btn go" id="goBtn"></button>' +
      '</div>' +
    '</div>' +
    '<div class="sheet" id="picker">' +
      '<header><h2 id="pickTitle">Include in the file</h2>' +
        '<button class="close" id="pickClose">&#x2715;</button></header>' +
      '<p class="hint" id="pickHint">Tap &#x2193; on a message to take it and everything after it.</p>' +
      '<div class="strip ask" id="askFull">' +
        '<span>This scrolls the thread to the top and unfolds messages as it goes. It takes a moment.</span>' +
        '<button class="btn minor" id="fullNo">Cancel</button>' +
        '<button class="btn warn" id="fullYes">Walk it</button></div>' +
      '<div class="strip work" id="scan"><span id="scanMsg">Reading the conversation&hellip;</span>' +
        '<button class="btn minor" id="scanStop">Stop</button></div>' +
      '<div class="actions aside" id="fullRow">' +
        '<button class="btn warn" id="pickFull">&#x2913; Walk the whole thread</button>' +
      '</div>' +
      '<div class="picks" id="pickList"></div>' +
      '<div class="actions">' +
        '<button class="btn minor" id="pickAll">All</button>' +
        '<button class="btn minor" id="pickNone">None</button>' +
        '<button class="btn minor" id="pickLast2">Last 2</button>' +
        '<button class="btn minor" id="pickLast6">Last 6</button>' +
      '</div>' +
      '<div class="actions last">' +
        '<button class="btn go" id="pickGo">&#x2B07; Download</button>' +
      '</div>' +
    '</div>' +
    '<div class="pad" id="pad">' +
      '<header><h2>Voice scratchpad</h2><button class="close" id="padClose">&#x2715;</button></header>' +
      '<div class="padwrap"><textarea class="padtext" id="padText" ' +
        'placeholder="Talk or type. Your keyboard\u2019s microphone works here too. ' +
        'Tap a word to select it, tap again for the sentence."></textarea></div>' +
      '<div class="padbar" id="padBar">' +
        '<button class="btn minor" id="padReword">&#x1F3A4; Say it again</button>' +
        '<button class="btn minor" id="padCut">Delete</button>' +
        '<button class="btn minor" id="padPick">&#xFF0B; Collect</button>' +
      '</div>' +
      '<div class="padask" id="padAsk"><span id="padAskMsg"></span>' +
        '<button class="btn minor" id="padAskNo">OK</button></div>' +
      '<div class="padfoot">' +
        '<button class="rec" id="padRec"><span class="dot"></span><span id="padRecLabel">Dictate</span></button>' +
      '</div>' +
      '<div class="actions">' +
        '<button class="btn minor" id="padCopy">&#x29C9; Copy</button>' +
        '<button class="btn minor" id="padClear">Clear</button>' +
      '</div>' +
      '<div class="actions last">' +
        '<button class="btn go" id="padSend"></button>' +
      '</div>' +
    '</div>' +
    '<div class="toast" id="toast"></div>';

  function attach() {
    var parent = document.body || document.documentElement;
    if (parent && !host.isConnected) {
      var ae = root.activeElement;
      parent.appendChild(host);
      // Re-appending the host drops focus inside the shadow root; restore it.
      if (ae && ae.focus) { try { ae.focus(); } catch (e) {} }
    }
  }
  attach();
  // SPA route changes occasionally rebuild <body>; make sure our UI survives.
  setInterval(attach, 2000);

  // SPA navigation between conversations never reloads the page, so watch the
  // URL and swap in the right fragment list when it changes.
  function checkRoute() {
    var k = convoKey();
    if (k === convo) return;
    var prev = convo;
    convo = k;
    clearPending();
    marks = [];
    hideChip();
    var map = loadJSON(MAP_KEY, {});
    var list = map[k] || [];
    // A batch collected in a fresh chat follows it once it gets a real id.
    if (!list.length && prev === location.hostname + ':draft' && map[prev] && map[prev].length) {
      list = map[prev];
      delete map[prev];
      map[k] = list;
      saveMap(MAP_KEY, map);
    }
    fragments = normalize(list);
    edGen++;                       // a new thread: place every editable again
    anchorSig = '';
    updatePill();
    redraw();
    if (sheetOpen) renderList();
  }
  setInterval(checkRoute, 800);

  var $ = function (id) { return root.getElementById(id); };
  var chip = $('chip'), pill = $('pill'), sheet = $('sheet');
  // Nothing to write into on a reading site, so the set is copied out instead.
  $('goBtn').innerHTML = IS_GITHUB ? '&#x29C9; Copy notes' : '&#x2197; To composer';
  var toastEl = $('toast'), listEl = $('list'), manualEl = $('manual');
  var hlLayer = $('hlLayer'), bar = $('bar'), notebox = $('notebox');

  // Focus guard for our text fields. Three layers:
  // 1. Key events targeted at our UI are stopped at window-capture, before
  //    the page's own capture- or bubble-phase hotkey handlers can see them.
  // 2. Pointer tracking distinguishes "the user tapped somewhere else" (a
  //    legitimate focus move) from "the page stole focus mid-typing" — a tap
  //    on the guarded field itself never counts as leaving it.
  // 3. On a steal, focus and the caret position are restored.
  var lastPointer = { ts: 0, target: null, inHost: false };
  var preTapActive = null, lastPointerType = '', tapStart = null, tapMoved = false;
  document.addEventListener('pointermove', function (e) {
    if (tapStart && Math.abs(e.clientX - tapStart.x) + Math.abs(e.clientY - tapStart.y) > 10) tapMoved = true;
  }, { capture: true, passive: true });
  document.addEventListener('pointerdown', function (e) {
    // Captured before the browser moves focus, so a tap can tell "already
    // editing here" from "just landed here".
    preTapActive = document.activeElement;
    lastPointerType = e.pointerType || '';
    tapStart = { x: e.clientX, y: e.clientY };
    tapMoved = false;
    lastPointer = { ts: Date.now(), target: null, inHost: e.target === host };
    // Before the browser decides what this tap means. Turning the card back
    // into text has to happen now or not at all: a moment later the caret is
    // already in it and the keyboard is on its way up.
    if (flatCards && e.target && e.target.nodeType === 1 && !host.contains(e.target)) {
      try { flattenCards(e.target); } catch (err) {}
    }
  }, true);
  root.addEventListener('pointerdown', function (e) {
    lastPointer = { ts: Date.now(), target: e.target, inHost: true };
  }, true);
  ['keydown', 'keypress', 'keyup'].forEach(function (t) {
    window.addEventListener(t, function (e) {
      if (e.target !== host) return;
      e.stopPropagation();
      // Target-phase listeners never fire once propagation stops, so the
      // notebox's Enter-to-add is handled here.
      if (t === 'keydown' && e.key === 'Enter' && root.activeElement === $('noteInput')) {
        noteboxAdd();
      }
    }, true);
  });
  var refocusLog = [];
  function pointerExplainsBlur(el) {
    if (Date.now() - lastPointer.ts >= 600) return false;
    // A fresh tap on this very field is how it GOT focus, not a reason to
    // give it up; any other recent tap is the user moving on.
    return !(lastPointer.inHost && lastPointer.target === el);
  }
  function guardInput(el) {
    ['keydown', 'keyup', 'keypress'].forEach(function (t) {
      el.addEventListener(t, function (e) { e.stopPropagation(); });
    });
    el.addEventListener('blur', function () {
      if (pointerExplainsBlur(el)) return;
      var now = Date.now();
      refocusLog = refocusLog.filter(function (ts) { return now - ts < 2000; });
      if (refocusLog.length >= 6) return; // don't fight a persistent page forever
      refocusLog.push(now);
      var caret = null;
      try { caret = el.selectionStart; } catch (e) {}
      setTimeout(function () {
        if (!el.isConnected || el.offsetParent === null) return;
        if (pointerExplainsBlur(el)) return;
        try {
          el.focus();
          if (typeof caret === 'number') el.setSelectionRange(caret, caret);
        } catch (e) {}
      }, 0);
    });
  }

  var toastTimer = null;
  function toast(msg, ms) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, ms || 1800);
  }

  function updatePill() {
    // Always reachable: the sheet also holds the conversation download
    // buttons, which are useful with zero fragments collected.
    var n = fragments.length;
    $('count').textContent = String(n);
    $('count').style.display = n ? 'flex' : 'none';
    // Compact shows one thing: the count, or an A when there is nothing yet.
    pill.classList.toggle('compact', compactPill);
    $('pillLabel').textContent = compactPill ? 'A' : 'Assay';
    $('pillLabel').style.display = (compactPill && n) ? 'none' : '';
    // The picker is a decision, not a place to keep collecting: the pill would
    // only sit over its rows.
    // (`picker` is bound further down; before that there is nothing to hide.)
    pill.classList.toggle('show', !((picker && picker.classList.contains('show')) ||
      (pad && pad.classList.contains('show'))));
    positionPill();
  }

  // Lift bottom-anchored UI above the on-screen keyboard, and dock popovers to
  // the visible part of the viewport (the keyboard shrinks visualViewport, not
  // the layout viewport, so fixed elements otherwise slide under it).
  function viewportInsets() {
    var vv = window.visualViewport;
    if (!vv) return { top: 0, left: 0, bottom: 0, height: window.innerHeight };
    return {
      top: vv.offsetTop,
      left: vv.offsetLeft,
      bottom: Math.max(0, window.innerHeight - vv.height - vv.offsetTop),
      height: vv.height
    };
  }
  function syncViewport() {
    var ins = viewportInsets();
    sheet.style.bottom = ins.bottom + 'px';
    sheet.style.maxHeight = Math.round(ins.height * 0.7) + 'px';
    if (notebox.classList.contains('show')) placeNotebox();
    positionPill();
  }
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', syncViewport);
    window.visualViewport.addEventListener('scroll', syncViewport);
  }

  // Where the button sits: wherever it was last dragged to, as an offset from
  // the nearer side and from the bottom of the visible viewport, so the
  // keyboard lifts it, a phone turned sideways still keeps it on the screen,
  // and a button parked against the left edge stays against the left edge
  // when it changes width. The open sheet pushes it up whatever the offset says.
  var PILL_KEY = 'assay.pill.v1';
  var pillPos = loadJSON(PILL_KEY, null);
  var compactPill = loadJSON(PILL_KEY, {}).compact === true;
  function positionPill() {
    var ins = viewportInsets();
    var w = pill.offsetWidth || 90, h = pill.offsetHeight || 46;
    var bottom = pillPos && typeof pillPos.bottom === 'number' ? pillPos.bottom : 110;
    bottom = Math.max(4, Math.min(bottom, ins.height - h - 4));
    if (sheetOpen && sheet.classList.contains('show')) {
      bottom = Math.max(bottom, sheet.offsetHeight + 12);
    }
    if (pillPos && typeof pillPos.left === 'number') {
      pill.style.left = Math.max(4, Math.min(pillPos.left, window.innerWidth - w - 4)) + 'px';
      pill.style.right = 'auto';
    } else {
      var right = pillPos && typeof pillPos.right === 'number' ? pillPos.right : 12;
      pill.style.right = Math.max(4, Math.min(right, window.innerWidth - w - 4)) + 'px';
      pill.style.left = 'auto';
    }
    pill.style.bottom = (ins.bottom + bottom) + 'px';
  }
  function savePill() {
    var o = { compact: compactPill };
    if (pillPos) { o.left = pillPos.left; o.right = pillPos.right; o.bottom = pillPos.bottom; }
    saveMap(PILL_KEY, o);
  }
  // Drag to move, by finger or mouse. A press that travels less than a few
  // pixels is a tap and opens the sheet as before; one that travels further is
  // a drag, and the click that follows it is swallowed so letting go does not
  // also open the sheet.
  var pillDrag = null, pillDragged = false;
  pill.addEventListener('pointerdown', function (e) {
    if (e.button && e.button !== 0) return;
    var r = pill.getBoundingClientRect(), ins = viewportInsets();
    pillDrag = { id: e.pointerId, x: e.clientX, y: e.clientY,
      right: window.innerWidth - r.right, bottom: window.innerHeight - r.bottom - ins.bottom };
    pillDragged = false;
    try { pill.setPointerCapture(e.pointerId); } catch (err) {}
  });
  pill.addEventListener('pointermove', function (e) {
    if (!pillDrag || e.pointerId !== pillDrag.id) return;
    var dx = e.clientX - pillDrag.x, dy = e.clientY - pillDrag.y;
    if (!pillDragged && Math.abs(dx) < 6 && Math.abs(dy) < 6) return;
    pillDragged = true;
    pill.classList.add('dragging');
    pillPos = { right: Math.round(pillDrag.right - dx), bottom: Math.round(pillDrag.bottom - dy) };
    positionPill();
    e.preventDefault();
  });
  function endPillDrag(e) {
    if (!pillDrag || e.pointerId !== pillDrag.id) return;
    pillDrag = null;
    pill.classList.remove('dragging');
    if (pillDragged) {
      // Keep what the clamp settled on, not where the finger went, anchored
      // to whichever side of the screen the button is nearer.
      var r = pill.getBoundingClientRect(), ins = viewportInsets();
      pillPos = { bottom: Math.round(window.innerHeight - r.bottom - ins.bottom) };
      if (r.left + r.width / 2 < window.innerWidth / 2) pillPos.left = Math.round(r.left);
      else pillPos.right = Math.round(window.innerWidth - r.right);
      savePill();
    }
  }
  pill.addEventListener('pointerup', endPillDrag);
  pill.addEventListener('pointercancel', endPillDrag);
  pill.addEventListener('click', function (e) {
    if (pillDragged) { pillDragged = false; e.stopImmediatePropagation(); e.preventDefault(); }
  }, true);
  window.addEventListener('resize', positionPill);
  // The sheet changes height as rows open and fragments arrive; the button
  // sits just above it, so it follows.
  if (window.ResizeObserver) {
    try { new ResizeObserver(function () { positionPill(); }).observe(sheet); } catch (e) {}
  }

  function addFragment(text, note, notePos, verb) {
    var frag = {
      id: Date.now() + '-' + Math.random().toString(36).slice(2, 7),
      text: text,
      note: note || '',
      notePos: notePos || 'post',
      verb: verbById(verb) ? verb : '',
      colorIdx: nextColorIdx(),
      ts: Date.now()
    };
    fragments.push(frag);
    persist();
    updatePill();
    if (sheetOpen) {
      // Append rather than rebuild: a full re-render would drop focus from a
      // note input the user is typing in.
      if (listEl.querySelector('.frag')) {
        listEl.appendChild(buildFragItem(fragments[fragments.length - 1], fragments.length - 1));
        $('goBtn').disabled = false;
        positionPill();
      } else {
        renderList();
      }
    }
    toast('Collected — ' + fragments.length + ' fragment' + (fragments.length > 1 ? 's' : ''));
    return frag;
  }

  // -------------------------------------------------- tap-to-collect engine
  // Tap a word to select it. Tap inside the highlight to widen the scope:
  // word → sentence → paragraph → back to the word. Tap a word outside the
  // highlight (same block) to grow the selection in that direction, word by
  // word. Collected fragments keep a tinted mark on the page for the session.
  var pending = null; // {block, flat, words, sentences, start, end, scope, aw0, aw1}
  var marks = [];     // session-only: {fid, blocks, start, end, colorIdx}
  // A tap on a passage already collected opens that fragment instead of
  // starting a new selection: the same bar, showing what it is filed as.
  var editing = null; // a fragment id

  function segmentSentences(text) {
    var out = [];
    if (window.Intl && Intl.Segmenter) {
      try {
        var seg = new Intl.Segmenter(undefined, { granularity: 'sentence' });
        var iter = seg.segment(text)[Symbol.iterator]();
        var step;
        while (!(step = iter.next()).done) {
          out.push({ start: step.value.index, end: step.value.index + step.value.segment.length });
        }
        if (out.length) return out;
      } catch (e) {}
    }
    var re = /[^.!?…]+[.!?…]*\s*/g, m;
    while ((m = re.exec(text))) out.push({ start: m.index, end: m.index + m[0].length });
    return out.length ? out : [{ start: 0, end: text.length }];
  }

  function segmentWords(text) {
    var out = [];
    if (window.Intl && Intl.Segmenter) {
      try {
        var seg = new Intl.Segmenter(undefined, { granularity: 'word' });
        var iter = seg.segment(text)[Symbol.iterator]();
        var step;
        while (!(step = iter.next()).done) {
          if (step.value.isWordLike) {
            out.push({ start: step.value.index, end: step.value.index + step.value.segment.length });
          }
        }
        if (out.length) return out;
      } catch (e) {}
    }
    var re = /\S+/g, m;
    while ((m = re.exec(text))) out.push({ start: m.index, end: m.index + m[0].length });
    return out;
  }

  function wordAt(words, off) {
    var best = null, bestDist = Infinity;
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      if (off >= w.start && off < w.end) return w;
      var d = off < w.start ? w.start - off : off - w.end + 1;
      if (d < bestDist) { bestDist = d; best = w; }
    }
    return bestDist <= 3 ? best : null;
  }

  function sentenceBounds(sentences, start, end) {
    var s0 = null, s1 = null;
    var last = Math.max(start, end - 1);
    for (var i = 0; i < sentences.length; i++) {
      if (s0 === null && start < sentences[i].end) s0 = sentences[i];
      if (last < sentences[i].end) { s1 = sentences[i]; break; }
    }
    if (!s0) s0 = sentences[0];
    if (!s1) s1 = sentences[sentences.length - 1];
    return { start: s0.start, end: s1.end };
  }

  // A selection lives inside one message and can span its paragraphs. Blocks
  // are the message's text-bearing elements, laid out on one virtual text
  // axis with a 2-char gap between blocks; words/sentences carry absolute
  // offsets on that axis.
  var BLOCK_SEL = 'p,li,blockquote,h1,h2,h3,h4,h5,h6,td,th,dd,dt,pre';

  // Most replies wrap paragraphs in <p>. A card that lays its lines out as
  // <div>s still has a block-level ancestor, and for our purposes that is the
  // paragraph.
  function blockAnchor(el) {
    var b = el.closest(BLOCK_SEL);
    if (b) return b;
    var n = el;
    while (n && n.nodeType === 1 && n !== document.body) {
      var d = '';
      try { d = window.getComputedStyle(n).display; } catch (e) { return null; }
      if (d && d.indexOf('inline') !== 0 && d !== 'contents') return n;
      n = n.parentElement;
    }
    return null;
  }

  // `light` skips word/sentence segmentation: re-anchoring marks only needs
  // the text axis and its nodes, and segmenting a whole conversation on every
  // attempt would be slow on a phone.
  function buildBlocks(container, light) {
    var walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null);
    var blocks = [], cur = null, n, lastEl = null, lastAnchor = null;
    while ((n = walker.nextNode())) {
      if (!n.nodeValue) continue;
      var el = n.parentElement;
      if (!el) continue;
      if (el.closest('button,[role="button"],svg,style,script')) continue;
      var anchor = el.closest(BLOCK_SEL) || (el === lastEl ? lastAnchor : (lastAnchor = blockAnchor(el), lastEl = el, lastAnchor));
      if (!anchor || !container.contains(anchor)) continue;
      if (!cur || cur.el !== anchor) {
        cur = { el: anchor, nodes: [], text: '' };
        blocks.push(cur);
      }
      cur.nodes.push({ node: n, start: cur.text.length, end: cur.text.length + n.nodeValue.length });
      cur.text += n.nodeValue;
    }
    blocks = blocks.filter(function (b) { return b.text.trim().length > 0; });
    var off = 0;
    blocks.forEach(function (b) {
      b.start = off;
      b.end = off + b.text.length;
      off = b.end + 2; // virtual paragraph gap
      if (light) return;
      var shift = function (seg) { return { start: seg.start + b.start, end: seg.end + b.start }; };
      b.words = segmentWords(b.text).map(shift);
      b.sentences = segmentSentences(b.text).map(shift);
    });
    return blocks;
  }

  function blockAt(blocks, off) {
    for (var i = 0; i < blocks.length; i++) {
      if (off >= blocks[i].start && off <= blocks[i].end) return blocks[i];
    }
    return null;
  }

  function absOffset(blocks, node, offset) {
    for (var i = 0; i < blocks.length; i++) {
      var b = blocks[i];
      for (var j = 0; j < b.nodes.length; j++) {
        if (b.nodes[j].node === node) return b.start + b.nodes[j].start + offset;
      }
    }
    return -1;
  }

  function domPointAbs(blocks, off) {
    var b = blockAt(blocks, off);
    if (!b) return null;
    var local = off - b.start;
    for (var i = 0; i < b.nodes.length; i++) {
      var e = b.nodes[i];
      if (local < e.end || i === b.nodes.length - 1) {
        return { node: e.node, offset: Math.max(0, Math.min(local - e.start, e.node.nodeValue.length)) };
      }
    }
    return null;
  }

  function rangeForSpan(blocks, start, end) {
    var a = domPointAbs(blocks, start);
    var b = domPointAbs(blocks, end);
    if (!a || !b) return null;
    try {
      var r = document.createRange();
      r.setStart(a.node, a.offset);
      r.setEnd(b.node, b.offset);
      return r;
    } catch (e) {
      return null;
    }
  }

  function rectsForSpan(blocks, start, end) {
    var r = rangeForSpan(blocks, start, end);
    if (!r) return null;
    var rects = r.getClientRects();
    return rects.length ? rects : null;
  }

  function caretPoint(x, y) {
    try {
      if (document.caretPositionFromPoint) {
        var p = document.caretPositionFromPoint(x, y);
        if (p) return { node: p.offsetNode, offset: p.offset };
      }
      if (document.caretRangeFromPoint) {
        var r = document.caretRangeFromPoint(x, y);
        if (r) return { node: r.startContainer, offset: r.startOffset };
      }
    } catch (e) {}
    return null;
  }

  function pendingText() {
    // Blocks are paragraphs in prose and lines in a code view: paragraphs read
    // apart, lines read together, and a line's indentation is part of it.
    var code = IS_GITHUB && pending.container.matches && pending.container.matches(GH_CODE);
    var parts = [];
    pending.blocks.forEach(function (b) {
      var s = Math.max(pending.start, b.start), e = Math.min(pending.end, b.end);
      if (e > s) {
        var t = b.text.slice(s - b.start, e - b.start);
        t = code ? t.replace(/\s+$/, '') : t.trim();
        if (t) parts.push(t);
      }
    });
    return parts.join(code ? '\n' : '\n\n');
  }

  function clearPending() {
    pending = null;
    if (editing) { editing = null; paintBar(); }
    bar.classList.remove('show');
    notebox.classList.remove('show');
    redraw();
  }

  function leaveEdit() {
    if (!editing) return;
    editing = null;
    paintBar();
  }

  function fragById(id) {
    for (var i = 0; i < fragments.length; i++) if (fragments[i].id === id) return fragments[i];
    return null;
  }
  function markById(id) {
    for (var i = 0; i < marks.length; i++) if (marks[i].fid === id) return marks[i];
    return null;
  }
  // The collected fragment under a tap, if there is one. Marks carry their own
  // blocks, so a stale one simply reports no hit.
  function markAtPoint(cp) {
    for (var i = marks.length - 1; i >= 0; i--) {
      var m = marks[i];
      var off = absOffset(m.blocks, cp.node, cp.offset);
      if (off >= 0 && off >= m.start && off <= m.end && fragById(m.fid)) return m;
    }
    return null;
  }

  // A highlight drawn as a box laid over the words has to be moved every time
  // the page scrolls, and on a phone scrolling is not the main thread's to keep
  // up with: the content is moved by the compositor and our boxes arrive a
  // frame or more later. That is precisely what "the highlight stays where it
  // was" looks like, and no amount of making the redraw cheaper fixes it,
  // because the redraw is never the thing that is late.
  //
  // So where the browser will paint a highlight into the text itself, it does.
  // A custom highlight is part of how the text is drawn: it moves with the
  // glyphs it sits on, for free, and scrolling stops involving us at all. The
  // boxes remain for browsers without it.
  var NATIVE_HL = (function () {
    try { return !!(window.Highlight && window.CSS && CSS.highlights); } catch (e) { return false; }
  })();
  var hlStyleEl = null, hlNames = {};
  // These styles have to live in the page's own stylesheet: a highlight paints
  // the page's text, which our shadow root has no say over.
  function installHighlightStyles() {
    if (hlStyleEl && hlStyleEl.isConnected) return;
    var css = '';
    for (var i = 0; i < PALETTE.length; i++) {
      css += '::highlight(assay-' + i + '){background-color:rgba(' + PALETTE[i].rgb + ',.26);color:inherit}' +
             '::highlight(assay-on-' + i + '){background-color:rgba(' + PALETTE[i].rgb + ',.48);color:inherit}';
    }
    hlStyleEl = document.createElement('style');
    hlStyleEl.setAttribute('data-assay', 'highlights');
    hlStyleEl.textContent = css;
    (document.head || document.documentElement).appendChild(hlStyleEl);
  }
  function applyHighlights(groups) {
    installHighlightStyles();
    var k;
    for (k in groups) {
      if (!groups.hasOwnProperty(k)) continue;
      var h = new Highlight();
      for (var i = 0; i < groups[k].length; i++) h.add(groups[k][i]);
      CSS.highlights.set('assay-' + k, h);
      hlNames[k] = true;
    }
    for (k in hlNames) {
      if (hlNames.hasOwnProperty(k) && !groups[k]) {
        CSS.highlights.delete('assay-' + k);
        delete hlNames[k];
      }
    }
  }
  // How many spans are painted right now, however they are being painted.
  function paintedCount() {
    if (!NATIVE_HL) return hlLayer.children.length;
    var n = 0;
    for (var k in hlNames) {
      if (!hlNames.hasOwnProperty(k)) continue;
      var h = CSS.highlights.get('assay-' + k);
      if (h) n += h.size;
    }
    return n;
  }
  function clearNativeHighlights() {
    for (var k in hlNames) {
      if (hlNames.hasOwnProperty(k)) CSS.highlights.delete('assay-' + k);
    }
    hlNames = {};
  }

  function paintRects(rects, color) {
    for (var i = 0; i < rects.length; i++) {
      var rc = rects[i];
      if (rc.width < 1 || rc.height < 1) continue;
      var d = document.createElement('div');
      d.className = 'hl';
      d.style.left = rc.left + 'px';
      d.style.top = rc.top + 'px';
      d.style.width = rc.width + 'px';
      d.style.height = rc.height + 'px';
      d.style.background = color;
      hlLayer.appendChild(d);
    }
  }

  // The rects a Range hands back are tight around the glyphs, so they
  // under-report how far apart two lines sit; the block's own line-height is
  // the distance a reader sees, and what the bar must clear.
  function linePitch(blocks, off, fallback) {
    var b = blockAt(blocks, off);
    if (b && b.el) {
      try {
        var cs = window.getComputedStyle(b.el);
        var lh = parseFloat(cs.lineHeight);
        if (lh > 0) return lh;
        var fs = parseFloat(cs.fontSize);
        if (fs > 0) return fs * 1.5;
      } catch (e) {}
    }
    return fallback * 1.6;
  }

  // The bar keeps a full line of clearance from the passage on whichever side
  // it sits, so the neighbouring line above and below both stay tappable and a
  // selection can grow in either direction. It prefers above (anchored to the
  // first line, so it holds still while you grow downward) and falls back to
  // below when the passage starts near the top edge.
  function placeBar(blocks, off, rects) {
    var last = rects[rects.length - 1];
    bar.classList.add('show');
    var vw = window.innerWidth, vh = window.innerHeight, ins = viewportInsets();
    var bw = bar.offsetWidth || 180, bh = bar.offsetHeight || 40;
    var left = Math.max(8, Math.min(last.left, vw - bw - 8));
    var lh = linePitch(blocks, off, last.height || rects[0].height || 16);
    var gap = Math.round(lh * 1.75) + 8;
    var top = rects[0].top - gap - bh;
    if (top < ins.top + 8) top = last.bottom + gap;
    if (top + bh > vh - ins.bottom - 8) top = Math.max(ins.top + 8, rects[0].top - gap - bh);
    bar.style.left = left + 'px';
    bar.style.top = top + 'px';
  }

  function redraw() {
    if (NATIVE_HL) return redrawNative();
    hlLayer.textContent = '';
    var editRects = null, editMark = null;
    // Session marks for already-collected fragments (drop dead ones quietly).
    marks = marks.filter(function (m) {
      var alive = m.blocks.some(function (b) { return b.el.isConnected; });
      if (!alive) return false;
      var rects = rectsForSpan(m.blocks, m.start, m.end);
      if (!rects) return false;
      // The one being edited reads like a live selection, not a past one.
      var on = m.fid === editing;
      paintRects(rects, 'rgba(' + PALETTE[m.colorIdx].rgb + (on ? ',.34)' : ',.18)'));
      if (on) { editRects = rects; editMark = m; }
      return true;
    });
    if (editing && !editMark) { editing = null; paintBar(); } // gone from the page
    if (editing) {
      placeBar(editMark.blocks, editMark.start, editRects);
      return;
    }
    if (!pending) { bar.classList.remove('show'); return; }
    var rects = rectsForSpan(pending.blocks, pending.start, pending.end);
    if (!rects) { pending = null; bar.classList.remove('show'); return; }
    paintRects(rects, 'rgba(' + PALETTE[nextColorIdx()].rgb + ',.34)');
    placeBar(pending.blocks, pending.start, rects);
  }

  // The same work, with the painting handed to the browser: no rects are
  // measured for a mark at all, so this costs nothing a scroll could be waiting
  // on. Only the bar needs to know where it is, and only while it is up.
  function redrawNative() {
    var groups = {}, editRange = null, editMark = null;
    function put(key, range) { (groups[key] || (groups[key] = [])).push(range); }
    marks = marks.filter(function (m) {
      if (!m.blocks.some(function (b) { return b.el.isConnected; })) return false;
      var r = rangeForSpan(m.blocks, m.start, m.end);
      if (!r) return false;
      var on = m.fid === editing;
      put((on ? 'on-' : '') + m.colorIdx, r);
      if (on) { editRange = r; editMark = m; }
      return true;
    });
    if (editing && !editMark) { editing = null; paintBar(); }
    if (editing) {
      applyHighlights(groups);
      placeBar(editMark.blocks, editMark.start, editRange.getClientRects());
      return;
    }
    if (!pending) {
      applyHighlights(groups);
      bar.classList.remove('show');
      return;
    }
    var pr = rangeForSpan(pending.blocks, pending.start, pending.end);
    var prRects = pr && pr.getClientRects();
    if (!prRects || !prRects.length) {
      pending = null;
      applyHighlights(groups);
      bar.classList.remove('show');
      return;
    }
    put('on-' + nextColorIdx(), pr);
    applyHighlights(groups);
    placeBar(pending.blocks, pending.start, prRects);
  }

  function placeNotebox() {
    var ins = viewportInsets();
    notebox.style.top = (ins.top + 10) + 'px';
    notebox.style.left = (ins.left + 8) + 'px';
  }

  function findBlock(el) {
    var block = el.closest ? blockAnchor(el) : null;
    if (!block || host.contains(block)) return null;
    var ed = block.closest(EDITABLE_SEL);
    if (ed && !host.contains(ed)) {
      // Inside the composer this is a draft; inside anything else editable —
      // a canvas card, a message being edited in place — it is a passage.
      // Short lines count there: a card is written in them.
      return isComposerEl(ed) ? null : block;
    }
    // On GitHub only the file itself is readable text; a line of code is
    // often short, so no length gate there.
    if (IS_GITHUB) return block.closest(GH_CONTENT) ? block : null;
    // Inside a reply, a short line is still a line worth taking.
    if (block.closest('[data-message-author-role="assistant"]')) return block;
    if (block.closest(TURN_SEL)) return block;
    if ((block.textContent || '').trim().length < 30) return null;
    var main = document.querySelector('main');
    if (main && main.contains(block)) return block;
    // Cards the site renders outside <main> still belong to the conversation.
    return block.closest(TURN_SEL) ? block : null;
  }

  // Editable regions in the page fall into two kinds, and only one of them is
  // off limits. The site's composer holds a draft you are writing. Everything
  // else editable — ChatGPT's inline canvas card, a message swapped into an
  // edit box in place — is rendered text you are reading, and reads like the
  // rest of the conversation.
  var RICH_SEL = '[contenteditable="true"],[contenteditable=""]';
  var EDITABLE_SEL = 'textarea,input,' + RICH_SEL;
  // Anything that might be one turn of a conversation. A class name that has
  // been renamed here costs you the tap, so this is deliberately a superset and
  // every name either site has used stays in it.
  var TURN_SEL = 'article,[data-message-author-role],[data-testid="user-message"],' +
    '[data-testid="assistant-message"],[data-is-streaming],' +
    '[class*="font-claude-message"],[class*="font-claude-response"],' +
    '[class*="font-user-message"],[class*="conversation-turn"]';

  function isComposerEl(ed) {
    if (!ed || !ed.closest) return false;
    if (ed.id === 'prompt-textarea') return true;
    if (ed.querySelector && ed.querySelector('#prompt-textarea')) return true;
    // Both sites have wrapped the composer in a form (ChatGPT) or a fieldset
    // (Claude); a card in the conversation sits in neither.
    if (ed.closest('form,fieldset')) return true;
    return !!ed.closest('[data-testid*="composer"],[class*="composer"],[class*="Composer"],' +
      '[data-testid*="chat-input"],[class*="chat-input"],[aria-label*="message" i]');
  }

  // Is this editable part of the conversation, or something else the page put
  // on screen? Only the conversation is ours to select in.
  //
  // This used to be asked the other way round — anything editable we could not
  // recognise as the composer was treated as a passage — and that default is
  // the wrong way up. Recognising the composer means knowing the names a site
  // currently uses, and the day Claude changed them every tap in the message
  // box was taken as a selection and had focus handed back, which is to say
  // typing stopped working. A site can rename whatever it likes; what it cannot
  // do is put its composer inside one of the conversation's own turns. So an
  // editable we cannot place is left alone, and the worst case is a card you
  // cannot select in rather than a chat you cannot type in.
  var edPlace = (typeof WeakMap === 'function') ? new WeakMap() : null;
  var edGen = 0;
  function inConversation(ed) {
    if (IS_GITHUB) return !!ed.closest(GH_CONTENT);
    if (ed.closest(TURN_SEL)) return true;            // cheap, and usually enough
    var was = edPlace && edPlace.get(ed);
    if (was && was.gen === edGen) return was.in;
    // Markup TURN_SEL does not name: ask the finder, which knows shapes
    // TURN_SEL cannot. It costs a pass over the page, so the answer is kept.
    var yes = false;
    try {
      var turns = liveTurns();
      for (var i = 0; i < turns.length; i++) {
        if (turns[i].el !== ed && turns[i].el.contains(ed)) { yes = true; break; }
      }
    } catch (e) {}
    if (edPlace) edPlace.set(ed, { gen: edGen, in: yes });
    return yes;
  }

  // ChatGPT drops a document into the middle of a reply — the canvas card — and
  // renders it into an editor. To the page that is an input; to you it is
  // something you are reading, and the editor fights every attempt to select in
  // it: the caret lands, the keyboard rises, the browser runs its own word
  // selection. So a card in the conversation is turned back into ordinary
  // conversation text — the words do not move, nothing is rewritten, the
  // element simply stops claiming to be editable — and then it reads and
  // selects like the prose around it.
  //
  // This is reversible and it is yours to reverse: the tray says "Cards: text"
  // or "Cards: editable", and nothing is ever done to the message box, to an
  // editable we cannot place inside a turn, or to one you are typing in.
  var FLAT_KEY = 'assay.flatCards.v1';
  var flatCards = loadJSON(FLAT_KEY, { on: true }).on !== false;
  var flattened = [];
  var FLAT_MIN = 120;      // shorter than this it is a field, not a document
  function flattenCards(near) {
    if (IS_GITHUB || !flatCards) return;
    // A tap only cares about the card under the finger; the tray asks for all
    // of them. Doing one is what keeps this off the critical path.
    var eds;
    if (near && near.closest) {
      var one = near.closest(RICH_SEL + ',textarea');
      eds = one ? [one] : [];
    } else {
      eds = document.querySelectorAll(RICH_SEL + ',textarea');
    }
    for (var i = 0; i < eds.length; i++) {
      var ed = eds[i];
      if (ed === host || host.contains(ed)) continue;
      if (ed.getAttribute('data-assay-flat')) continue;
      if (isComposerEl(ed)) continue;                       // never the message box
      if (document.activeElement === ed || ed.contains(document.activeElement)) continue;
      var text = ed.value != null ? ed.value : (ed.textContent || '');
      if ((text || '').trim().length < FLAT_MIN) continue;  // a field, not a card
      if (!inConversation(ed)) continue;                    // must be in the thread
      if (ed.tagName === 'TEXTAREA' || ed.tagName === 'INPUT') {
        if (ed.readOnly) continue;
        ed.readOnly = true;
        flattened.push({ el: ed, kind: 'ro' });
      } else {
        flattened.push({ el: ed, kind: 'ce', was: ed.getAttribute('contenteditable') });
        ed.setAttribute('contenteditable', 'false');
      }
      ed.setAttribute('data-assay-flat', '1');
    }
  }
  function unflattenCards() {
    flattened.forEach(function (f) {
      try {
        if (f.kind === 'ro') f.el.readOnly = false;
        else if (f.was == null) f.el.removeAttribute('contenteditable');
        else f.el.setAttribute('contenteditable', f.was);
        f.el.removeAttribute('data-assay-flat');
      } catch (e) {}
    });
    flattened = [];
  }

  // The editable the tap landed in, when that editable is conversation.
  function pageEditable(el, sel) {
    if (!el || !el.closest) return null;
    var ed = el.closest(sel || EDITABLE_SEL);
    if (!ed || ed === host || host.contains(ed)) return null;
    if (isComposerEl(ed)) return null;
    return inConversation(ed) ? ed : null;
  }

  // The message that a tapped block belongs to; blocks fall back to
  // themselves on unknown layouts, giving single-paragraph behavior there.
  function findContainer(block) {
    // A canvas card is a document of its own: keep growth inside it rather
    // than letting a selection run out into the reply around it.
    var ed = pageEditable(block, RICH_SEL);
    if (ed) return ed;
    // A file (or one rendered comment) is the document a selection grows in.
    if (IS_GITHUB) return block.closest(GH_CONTENT) || block;
    // The turn is the document a selection grows in — every name for it, since
    // one that has been renamed silently costs you growth past a paragraph.
    return block.closest(TURN_SEL) || block;
  }

  function beginPending(container, blocks, foff) {
    var b = blockAt(blocks, foff);
    var w = b && wordAt(b.words, foff);
    if (!w) return false;
    pending = {
      container: container,
      blocks: blocks,
      start: w.start,
      end: w.end,
      scope: 'word',
      aw0: w.start,
      aw1: w.end
    };
    return true;
  }

  function cycleScope() {
    var p = pending;
    if (p.scope === 'paragraph') {
      p.start = p.aw0; p.end = p.aw1; p.scope = 'word';
      return;
    }
    var bs = blockAt(p.blocks, p.start);
    var be = blockAt(p.blocks, Math.max(p.start, p.end - 1));
    if (!bs || !be) return;
    if (p.scope === 'sentence') {
      p.start = bs.start; p.end = be.end; p.scope = 'paragraph';
      return;
    }
    // word or custom → the sentence(s) covering the current selection
    // (per touched block); if that changes nothing, go straight to the
    // full paragraph(s).
    var s0 = sentenceBounds(bs.sentences, p.start, Math.min(p.end, bs.end));
    var s1 = sentenceBounds(be.sentences, Math.max(p.start, be.start), p.end);
    if (s0.start === p.start && s1.end === p.end) {
      p.start = bs.start; p.end = be.end; p.scope = 'paragraph';
    } else {
      p.start = s0.start; p.end = s1.end; p.scope = 'sentence';
    }
  }

  document.addEventListener('click', function (e) {
    if (e.target === host) return;
    var el = e.target && e.target.nodeType === 1 ? e.target : (e.target ? e.target.parentElement : null);
    if (!el || host.contains(el)) return;
    var onControl = el.closest && el.closest('a,button,select,[role="button"],svg');
    // Text in a rich editable that isn't the composer — ChatGPT's inline
    // canvas card, a message being edited in place — is read like any other
    // passage, so a tap there selects.
    var card = onControl ? null : pageEditable(el, RICH_SEL);
    // On a touchscreen the caret must not stay behind: the keyboard would
    // cover what you are reading. So we hand focus back after each tap —
    // which also means a card that already holds focus holds it deliberately
    // (the site's own edit control put it there), and we leave it alone. With
    // a mouse there is no keyboard to raise, so the caret can stay and the
    // card stays editable by clicking into it.
    var touch = lastPointerType === 'touch';
    if (card && touch && (preTapActive === card || card.contains(preTapActive))) return;
    if (!card && el.closest && el.closest('a,button,input,textarea,select,' + RICH_SEL + ',[role="button"],svg')) {
      // Tapping into an edit box means "I am editing", not "start over":
      // keep what is already selected behind it.
      if (!pageEditable(el)) clearPending();
      return;
    }
    var sel = window.getSelection();
    if (sel && !sel.isCollapsed) {
      // Inside a card the browser makes its own selection: tapping a word a
      // second time selects it, a third time takes the paragraph — which
      // would hijack the scope cycle. A selection the user dragged out (or
      // long-pressed) is theirs, so only a tap that never moved is dropped.
      if (!card || tapMoved) return; // that selection is the user's
      try { sel.removeAllRanges(); } catch (e2) {}
    }
    var block = findBlock(el);
    if (!block) { clearPending(); return; }
    var cp = caretPoint(e.clientX, e.clientY);
    if (!cp) { clearPending(); return; }

    var container = findContainer(block);
    if (card && touch) { try { card.blur(); } catch (e) {} }

    // Widening the selection you are holding comes first; after that, a tap on
    // a passage already collected opens that fragment rather than starting
    // something new.
    var insidePending = false;
    if (pending && pending.container === container) {
      var po = absOffset(pending.blocks, cp.node, cp.offset);
      insidePending = po >= 0 && po >= pending.start && po <= pending.end;
    }
    if (!insidePending) {
      var hit = markAtPoint(cp);
      if (hit) {
        pending = null;
        editing = hit.fid;
        hideChip();
        notebox.classList.remove('show');
        paintBar();
        redraw();
        return;
      }
    }
    leaveEdit();
    if (pending && pending.container === container) {
      // Same message: grow (across paragraphs too) or cycle the scope.
      // Restarting here is deliberate friction — ✕ on the bar, or tap a
      // different message / empty space to start over.
      var off = absOffset(pending.blocks, cp.node, cp.offset);
      if (off >= 0) {
        if (off >= pending.start && off <= pending.end) {
          cycleScope();
          redraw();
          return;
        }
        var b2 = blockAt(pending.blocks, off);
        var w = b2 && wordAt(b2.words, off);
        if (w) {
          // Growing is for the passage in hand: the paragraph you are in, or
          // the one against it. A tap further off is a different passage, so
          // it starts a new selection there rather than dragging the
          // highlight across everything in between. Reaching a paragraph
          // beyond the next one is a tap at a time.
          var bi = pending.blocks.indexOf(b2);
          var lo = pending.blocks.indexOf(blockAt(pending.blocks, pending.start));
          var hi = pending.blocks.indexOf(blockAt(pending.blocks, Math.max(pending.start, pending.end - 1)));
          if (bi >= lo - 1 && bi <= hi + 1) {
            if (off >= pending.end) pending.end = Math.max(pending.end, w.end);
            else pending.start = Math.min(pending.start, w.start);
            pending.scope = 'custom';
          } else if (!beginPending(container, pending.blocks, off)) {
            clearPending();
            return;
          }
          redraw();
          return;
        }
      }
      // Stale nodes (the site re-rendered): fall through and rebuild.
    }
    var blocks = buildBlocks(container);
    var foff = absOffset(blocks, cp.node, cp.offset);
    if (foff < 0) { clearPending(); return; }
    hideChip();
    notebox.classList.remove('show');
    if (!beginPending(container, blocks, foff)) { clearPending(); return; }
    redraw();
  });

  function collectPending(note, notePos, verb) {
    var p = pending;
    var frag = addFragment(pendingText(), note, notePos, verb);
    marks.push({ fid: frag.id, blocks: p.blocks, start: p.start, end: p.end, colorIdx: frag.colorIdx });
    clearPending();
  }

  // Renders the verb chips into a container; `onPick` gets the verb id and
  // `isOn` says which chip (if any) shows as selected.
  function renderVerbs(container, onPick, isOn) {
    container.textContent = '';
    VERBS.forEach(function (v) {
      var b = document.createElement('button');
      b.className = 'vb' + (isOn && isOn(v.id) ? ' on' : '');
      b.textContent = v.label;
      b.title = v.clause;
      b.addEventListener('click', function () { onPick(v.id); });
      container.appendChild(b);
    });
  }

  $('addBtn').addEventListener('click', function () {
    if (pending) collectPending();
  });
  $('cancelBtn').addEventListener('click', clearPending);
  $('removeBtn').addEventListener('click', function () {
    if (!editing) return;
    var id = editing;
    fragments = fragments.filter(function (x) { return x.id !== id; });
    marks = marks.filter(function (m) { return m.fid !== id; });
    editing = null;
    persist(); updatePill(); redraw();
    if (sheetOpen) renderList();
    toast('Removed');
  });

  // The bar wears one of two faces. Collecting: ＋ Add, ✎ Note, and a verb
  // collects in one tap. Editing a passage already collected: its number, a
  // note to rewrite, Remove, and the verbs showing how it is filed.
  function paintBar() {
    var f = editing ? fragById(editing) : null;
    if (f) {
      var i = fragments.indexOf(f);
      var tag = $('editTag');
      tag.textContent = String(i + 1);
      tag.style.background = PALETTE[f.colorIdx].badgeBg;
      tag.style.color = PALETTE[f.colorIdx].badgeInk;
      tag.hidden = false;
      $('addBtn').hidden = true;
      $('removeBtn').hidden = false;
      renderVerbs($('barVerbs'), function (id) {
        f.verb = f.verb === id ? '' : id;
        persist();
        paintBar();
        if (sheetOpen) renderList();
      }, function (v) { return f.verb === v; });
      return;
    }
    $('editTag').hidden = true;
    $('addBtn').hidden = false;
    $('removeBtn').hidden = true;
    // One tap on a verb collects the passage classified — the bike-native
    // path: no keyboard, no note, the verb carries the intent.
    renderVerbs($('barVerbs'), function (id) {
      if (pending) collectPending('', 'post', id);
    });
  }
  paintBar();

  var notePos = 'post';
  function setNotePos(p) {
    notePos = p;
    $('posPre').classList.toggle('on', p === 'pre');
    $('posPost').classList.toggle('on', p === 'post');
  }
  $('posPre').addEventListener('click', function () { setNotePos('pre'); });
  $('posPost').addEventListener('click', function () { setNotePos('post'); });
  var noteVerb = '';
  function setNoteVerb(id) {
    noteVerb = noteVerb === id ? '' : id;
    renderVerbs($('noteVerbs'), setNoteVerb, function (v) { return v === noteVerb; });
  }
  $('noteBtn').addEventListener('click', function () {
    var f = editing ? fragById(editing) : null;
    if (!pending && !f) return;
    setNotePos(f ? (f.notePos || 'post') : 'post');
    noteVerb = f ? (f.verb || '') : '';
    renderVerbs($('noteVerbs'), setNoteVerb, function (v) { return v === noteVerb; });
    $('noteInput').value = f ? (f.note || '') : '';
    $('noteAdd').textContent = f ? 'Save' : 'Add';
    $('noteInput').classList.remove('tall');
    $('noteInput').style.height = '';
    notebox.classList.add('show');
    placeNotebox();
    $('noteInput').focus();
  });
  function noteboxAdd() {
    var f = editing ? fragById(editing) : null;
    if (f) {
      f.note = $('noteInput').value.trim();
      f.notePos = notePos;
      f.verb = noteVerb;
      persist();
      notebox.classList.remove('show');
      paintBar();
      if (sheetOpen) renderList();
      toast('Saved');
      return;
    }
    if (!pending) { notebox.classList.remove('show'); return; }
    collectPending($('noteInput').value.trim(), notePos, noteVerb);
  }
  $('noteAdd').addEventListener('click', noteboxAdd);
  $('noteInput').addEventListener('keydown', function (e) {
    // It grew a second dimension for dictation, but it is still a one-line
    // thought: Enter adds it. Shift-Enter is there if you really want a break.
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); noteboxAdd(); }
  });
  guardInput($('noteInput'));
  guardInput($('manualTxt'));

  // ------------------------------------------ restoring marks after a reload
  // Marks hang off live DOM nodes, so a refresh — or the site re-rendering a
  // message — wipes the highlights while the fragments themselves persist in
  // storage. Find each orphaned fragment's text in the conversation again and
  // re-attach its mark, so a reload looks like nothing happened.
  function messageContainers() {
    if (IS_GITHUB) {
      var gh = document.querySelectorAll(GH_CONTENT);
      return Array.prototype.slice.call(gh).filter(function (el) { return !host.contains(el); });
    }
    var nodes = document.querySelectorAll(TURN_SEL);
    var list = nodes.length ? Array.prototype.slice.call(nodes) : [];
    if (!list.length) {
      var main = document.querySelector('main');
      if (main) list = [main];
    }
    return list.filter(function (el) { return !host.contains(el); });
  }

  // The flat text of the axis buildBlocks lays out, gaps included, so an
  // offset found here is an offset a mark can use directly.
  function flatOf(blocks) {
    var s = '';
    blocks.forEach(function (b) {
      while (s.length < b.start) s += ' ';
      s += b.text;
    });
    return s;
  }

  function findSpan(flat, parts, from) {
    var s = flat.indexOf(parts[0], from);
    if (s < 0) return null;
    var e = s + parts[0].length;
    for (var i = 1; i < parts.length; i++) {
      var k = flat.indexOf(parts[i], e);
      if (k < 0) return null;
      e = k + parts[i].length;
    }
    return { start: s, end: e };
  }

  function overlaps(used, span) {
    return used.some(function (u) { return span.start < u.end && u.start < span.end; });
  }

  function reanchorMarks() {
    var have = {};
    marks.forEach(function (m) { have[m.fid] = true; });
    var missing = fragments.filter(function (f) { return !have[f.id]; });
    if (!missing.length) return 0;
    var containers = messageContainers();
    if (!containers.length) return 0;

    var cache = [];
    function ctx(el) {
      for (var i = 0; i < cache.length; i++) if (cache[i].el === el) return cache[i];
      var blocks = buildBlocks(el, true);
      var c = { el: el, blocks: blocks, flat: flatOf(blocks), used: [] };
      // Spans already spoken for by a live mark in this container.
      marks.forEach(function (m) {
        if (m.blocks.length && blocks.length && m.blocks[0].el === blocks[0].el) {
          c.used.push({ start: m.start, end: m.end });
        }
      });
      cache.push(c);
      return c;
    }

    var added = 0;
    missing.forEach(function (f) {
      var parts = (f.text || '').split(/\n+/).map(function (t) { return t.trim(); })
        .filter(function (t) { return t.length; });
      if (!parts.length) return;
      var span = 0;
      parts.forEach(function (t) { span += t.length; });
      var limit = span + 200;
      for (var i = 0; i < containers.length; i++) {
        if (containers[i].textContent.indexOf(parts[0]) < 0) continue; // cheap pre-filter
        var c = ctx(containers[i]);
        var from = 0, hit;
        while ((hit = findSpan(c.flat, parts, from))) {
          if (!overlaps(c.used, hit)) break;
          from = hit.start + 1;
        }
        if (!hit || hit.end - hit.start > limit) continue;
        c.used.push(hit);
        marks.push({ fid: f.id, blocks: c.blocks, start: hit.start, end: hit.end, colorIdx: f.colorIdx });
        added++;
        return;
      }
    });
    return added;
  }

  // Messages stream in and lazy-render, so try a few times and start over
  // whenever the conversation or the fragment list changes.
  var anchorTries = 0, anchorSig = '';
  function maybeReanchor() {
    if (!fragments.length) return;
    var have = {};
    marks.forEach(function (m) { have[m.fid] = true; });
    var missing = fragments.some(function (f) { return !have[f.id]; });
    if (!missing) return;
    var sig = document.querySelectorAll(TURN_SEL).length + ':' + fragments.length;
    if (sig !== anchorSig) { anchorSig = sig; anchorTries = 4; }
    if (anchorTries <= 0) return;
    anchorTries--;
    if (reanchorMarks()) redraw();
  }
  setInterval(maybeReanchor, 1200);

  setTimeout(maybeReanchor, 400);

  var redrawScheduled = false;
  function scheduleRedraw() {
    if (redrawScheduled) return;
    if (!pending && !editing && (NATIVE_HL || !marks.length)) return;
    redrawScheduled = true;
    requestAnimationFrame(function () {
      redrawScheduled = false;
      redraw();
    });
  }
  // Where the browser paints the highlights, a scroll with nothing but marks on
  // screen has nothing for us to do, and the listener returns on its first line.
  window.addEventListener('scroll', scheduleRedraw, true);
  window.addEventListener('resize', scheduleRedraw);

  // ----------------------------------------- long-press selection (fallback)
  var selPendingText = '';
  function hideChip() { chip.classList.remove('show'); }

  function showChip(rect) {
    chip.classList.add('show');
    var vw = window.innerWidth, vh = window.innerHeight;
    var cw = chip.offsetWidth || 110, ch = chip.offsetHeight || 40;
    var left = 12, top = vh - ch - 90;
    if (rect && rect.width + rect.height > 0) {
      left = rect.left + rect.width / 2 - cw / 2;
      // Below the selection: Android's native text menu appears above it.
      top = rect.bottom + 14;
      if (top + ch > vh - 12) top = rect.top - ch - 14;
    }
    chip.style.left = Math.max(8, Math.min(left, vw - cw - 8)) + 'px';
    chip.style.top = Math.max(8, Math.min(top, vh - ch - 8)) + 'px';
  }

  var selTimer = null;
  function queueSelection() {
    clearTimeout(selTimer);
    selTimer = setTimeout(onSelection, 250);
  }
  document.addEventListener('selectionchange', queueSelection);
  // Not every browser reports a textarea's selection through selectionchange.
  document.addEventListener('select', queueSelection, true);

  // A <textarea>/<input> keeps its selection to itself: window.getSelection()
  // reports nothing, so read it off the element instead.
  function editorSelection() {
    var ae = document.activeElement;
    if (!ae || !ae.tagName) return null;
    var tag = ae.tagName.toLowerCase();
    if (tag !== 'textarea' && tag !== 'input') return null;
    if (!pageEditable(ae)) return null;
    try {
      var a = ae.selectionStart, b = ae.selectionEnd;
      if (a == null || b == null || b - a < MIN_SEL_LEN) return null;
      var text = String(ae.value || '').slice(a, b).trim();
      if (text.length < MIN_SEL_LEN) return null;
      return { el: ae, text: text };
    } catch (e) { return null; }
  }

  function onSelection() {
    var inEditor = editorSelection();
    if (inEditor) {
      clearPending();
      selPendingText = inEditor.text;
      showChip(inEditor.el.getBoundingClientRect());
      return;
    }
    var sel = window.getSelection();
    if (!sel || sel.isCollapsed || sel.rangeCount === 0) { hideChip(); return; }
    var text = sel.toString().trim();
    if (text.length < MIN_SEL_LEN) { hideChip(); return; }
    var node = sel.anchorNode;
    var el = node ? (node.nodeType === 1 ? node : node.parentElement) : null;
    if (!el || host.contains(el)) return;
    // Text in the site's own composer is a draft, not a passage.
    if (el.closest && el.closest(EDITABLE_SEL) && !pageEditable(el)) {
      hideChip();
      return;
    }
    clearPending();
    selPendingText = text;
    var rect = null;
    try { rect = sel.getRangeAt(0).getBoundingClientRect(); } catch (e) {}
    showChip(rect);
  }

  window.addEventListener('scroll', hideChip, true);

  chip.addEventListener('pointerdown', function (e) {
    e.preventDefault();
    e.stopPropagation();
    if (!selPendingText) return;
    addFragment(selPendingText);
    selPendingText = '';
    hideChip();
    anchorSig = '';
    maybeReanchor(); // paint its highlight now rather than on the next tick
    try { window.getSelection().removeAllRanges(); } catch (err) {}
  });

  // ------------------------------------------------------------------ sheet
  // Non-modal: the conversation stays visible and scrollable behind it, taps
  // still collect while it's open, and the pill rides above it as a toggle.
  function openSheet() {
    sheetOpen = true;
    try { flattenCards(); } catch (e) {}
    hideChip();
    clearPending();
    renderList();
    manualEl.classList.remove('show');
    sheet.classList.add('show');
    syncViewport();
    updatePill();
  }
  function closeSheet() {
    sheetOpen = false;
    sheet.classList.remove('show');
    updatePill();
  }
  function toggleSheet() { sheetOpen ? closeSheet() : openSheet(); }

  pill.addEventListener('click', toggleSheet);
  $('closeBtn').addEventListener('click', closeSheet);

  function renderList() {
    // Rebuilding destroys a note input the user may be typing in (e.g. a
    // route-watcher refresh) — carry focus and caret across the rebuild.
    var focusFid = null, focusCaret = 0;
    var ae = root.activeElement;
    if (ae && ae.tagName === 'INPUT' && ae.getAttribute('data-fid')) {
      focusFid = ae.getAttribute('data-fid');
      try { focusCaret = ae.selectionStart || 0; } catch (e) {}
    }
    listEl.textContent = '';
    if (!fragments.length) {
      var empty = document.createElement('div');
      empty.className = 'empty';
      empty.textContent = 'Nothing collected here yet. Tap a word in the ' + READ_NOUN +
        ' — tap the highlight to widen it (word → sentence → paragraph), tap nearby words to grow it — or long-press to select any span.';
      var backup = loadBackup();
      if (backup && backup.length) {
        empty.appendChild(document.createElement('br'));
        var restore = document.createElement('button');
        restore.className = 'restore';
        restore.textContent = 'Restore last batch (' + backup.length + ')';
        restore.addEventListener('click', function () {
          fragments = normalize(backup);
          persist(); updatePill(); renderList();
        });
        empty.appendChild(restore);
      }
      listEl.appendChild(empty);
      $('goBtn').disabled = true;
      positionPill();
      return;
    }
    $('goBtn').disabled = false;
    fragments.forEach(function (f, i) {
      listEl.appendChild(buildFragItem(f, i));
    });
    if (focusFid) {
      var again = listEl.querySelector('input[data-fid="' + focusFid + '"]');
      if (again) {
        try { again.focus(); again.setSelectionRange(focusCaret, focusCaret); } catch (e) {}
      }
    }
    positionPill();
  }

  function buildFragItem(f, i) {
    var item = document.createElement('div');
    item.className = 'frag';

    var top = document.createElement('div');
    top.className = 'top';

    var idx = document.createElement('span');
    idx.className = 'idx';
    idx.textContent = String(i + 1);
    idx.style.background = PALETTE[f.colorIdx].badgeBg;
    idx.style.color = PALETTE[f.colorIdx].badgeInk;

    var txt = document.createElement('div');
    txt.className = 'txt';
    txt.textContent = f.text;
    txt.addEventListener('click', function () { txt.classList.toggle('full'); });

    var del = document.createElement('button');
    del.className = 'del';
    del.textContent = '✕';
    del.addEventListener('click', function () {
      fragments = fragments.filter(function (x) { return x.id !== f.id; });
      // Its tinted mark on the page goes with it.
      marks = marks.filter(function (m) { return m.fid !== f.id; });
      persist(); updatePill(); renderList(); redraw();
    });

    top.appendChild(idx); top.appendChild(txt); top.appendChild(del);

    var row = document.createElement('div');
    row.className = 'noterow';

    var note = document.createElement('input');
    note.type = 'text';
    note.placeholder = 'annotation (now or later)';
    note.value = f.note || '';
    note.setAttribute('data-fid', f.id);
    note.addEventListener('input', function () { f.note = note.value; persist(); });
    guardInput(note);

    var pos = document.createElement('button');
    pos.className = 'pos';
    pos.textContent = f.notePos === 'pre' ? 'before' : 'after';
    pos.title = 'Where the annotation sits relative to the quote';
    pos.addEventListener('click', function () {
      f.notePos = f.notePos === 'pre' ? 'post' : 'pre';
      pos.textContent = f.notePos === 'pre' ? 'before' : 'after';
      persist();
    });

    // Tap cycles none → keep → push → fix → challenge → cut → none, so a
    // verb can be set or changed later without a keyboard.
    var vb = document.createElement('button');
    vb.className = 'pos verb';
    function paintVerb() {
      var v = verbById(f.verb);
      vb.textContent = v ? v.label : 'verb';
      vb.title = v ? v.clause : 'Classify this fragment';
      vb.classList.toggle('on', !!v);
    }
    paintVerb();
    vb.addEventListener('click', function () {
      var i = -1;
      VERBS.forEach(function (v, k) { if (v.id === f.verb) i = k; });
      f.verb = i + 1 < VERBS.length ? VERBS[i + 1].id : '';
      paintVerb();
      persist();
    });

    row.appendChild(note); row.appendChild(vb); row.appendChild(pos);
    item.appendChild(top);
    item.appendChild(row);
    return item;
  }

  $('clearBtn').addEventListener('click', function () {
    if (!fragments.length) { closeSheet(); return; }
    saveBackup();
    fragments = [];
    marks = [];
    persist(); updatePill(); renderList(); redraw();
    toast('Cleared (restorable from the sheet)');
  });

  // ------------------------------------------------------- payload & export
  // No wrapper prompt: the payload is the fragments and their annotations.
  // The leading clause before a quote: the verb's plain-English reading, a
  // `pre` note, or both joined with a dash.
  function leadClause(f) {
    var v = verbById(f.verb);
    var note = (f.note || '').trim();
    var parts = [];
    if (v) parts.push(v.clause);
    if (note && f.notePos === 'pre') parts.push(note);
    return parts.join(' — ');
  }
  // Prose is trimmed. A multi-line fragment keeps its indentation: in a code
  // view that is part of what was selected.
  function fragText(f) {
    var t = f.text || '';
    return t.indexOf('\n') === -1 ? t.trim() : t.replace(/^[ \t]*\n/, '').replace(/\s+$/, '');
  }

  function buildPayload() {
    var many = fragments.length > 1;
    return fragments.map(function (f, i) {
      var head = many ? (i + 1) + '. ' : '';
      var note = (f.note || '').trim();
      var lead = leadClause(f);
      var lines = [];
      if (lead) {
        lines.push(head + lead + ':');
        lines.push('“' + fragText(f) + '”');
      } else {
        lines.push(head + '“' + fragText(f) + '”');
      }
      if (note && f.notePos !== 'pre') lines.push('→ ' + note);
      return lines.join('\n');
    }).join('\n\n');
  }

  function two(n) { return (n < 10 ? '0' : '') + n; }
  function niceStamp() {
    var d = new Date();
    return d.getFullYear() + '-' + two(d.getMonth() + 1) + '-' + two(d.getDate()) +
      ' ' + two(d.getHours()) + ':' + two(d.getMinutes());
  }
  function fileStamp() {
    return niceStamp().replace(' ', '-').replace(':', '');
  }

  // -------------------------------------------- whole-conversation capture
  function textOf(el) {
    var t = (el.innerText || '').replace(/\u00a0/g, ' ').trim();
    // The screen-reader label is not part of what was said.
    t = unlabel(t);
    // innerText stops at an editing block's boundary, so a card rendered into a
    // textarea reads as empty. Its value is the text that is on the screen.
    if (el.querySelectorAll) {
      var fields = el.querySelectorAll('textarea,input[type="text"]');
      for (var i = 0; i < fields.length; i++) {
        if (isComposerEl(fields[i])) continue;
        var v = String(fields[i].value == null ? '' : fields[i].value).trim();
        if (v && t.indexOf(v) < 0) t = t ? t + '\n' + v : v;
      }
    }
    return t;
  }

  // Light DOM→markdown for rendered chat messages: block structure only
  // (paragraphs, headings, lists, code fences, quotes); inline styling is
  // dropped. Robust beats faithful here.
  // A classic GitHub code table (github.com's legacy view, and every gist —
  // gist never got the newer react-code-lines markup) pairs an empty
  // line-number <td> with a code <td> in each row. Reading the table's own
  // innerText joins the two cells with a tab per row, which would land in
  // every exported line; reading each row's own code cell instead avoids it.
  function codeTableText(table) {
    var rows = table.querySelectorAll('tr');
    if (!rows.length) return null;
    return Array.prototype.map.call(rows, function (tr) {
      var cells = tr.querySelectorAll('td');
      var cell = cells[cells.length - 1];
      return cell ? cell.textContent.replace(/\n+$/, '') : '';
    }).join('\n');
  }

  function serializeBlocks(rootEl) {
    var out = [];
    // A code view is lines of text, not prose: keep it verbatim in a fence.
    if (rootEl.matches && rootEl.matches(GH_CODE)) {
      var table = rootEl.tagName === 'TABLE' ? rootEl : rootEl.querySelector('table');
      var code = ((table && codeTableText(table)) || rootEl.innerText || '').replace(/\s+$/, '');
      return code ? ['```\n' + code + '\n```'] : [];
    }
    function pushText(s) { if (s) out.push(s); }
    function walk(node) {
      if (node.nodeType !== 1 || node === host) return;
      var tag = node.tagName;
      var cls = (node.className && node.className.indexOf ? node.className : '') + '';
      if (/\bsr-only\b|visually-hidden/.test(cls)) return;     // said to screen readers, not to you
      var h = /^H([1-6])$/.exec(tag);
      if (h) {
        var ht = textOf(node);
        if (ht) pushText(new Array(+h[1] + 1).join('#') + ' ' + ht);
        return;
      }
      if (tag === 'P') { pushText(textOf(node)); return; }
      if (tag === 'PRE') {
        var code = node.querySelector('code');
        var t = ((code || node).innerText || '').replace(/\s+$/, '');
        if (t) out.push('```\n' + t + '\n```');
        return;
      }
      if (tag === 'UL' || tag === 'OL') {
        var items = node.querySelectorAll(':scope > li');
        Array.prototype.forEach.call(items, function (li, i) {
          pushText((tag === 'OL' ? (i + 1) + '. ' : '- ') + textOf(li).replace(/\n+/g, ' '));
        });
        return;
      }
      if (tag === 'BLOCKQUOTE') {
        var q = textOf(node);
        if (q) out.push(q.split('\n').map(function (l) { return '> ' + l; }).join('\n'));
        return;
      }
      if (tag === 'TABLE') { pushText(textOf(node)); return; }
      // An editing block the site dropped into the conversation — a canvas card
      // in a textarea, a message swapped into an edit box — keeps its words in
      // .value, where innerText never looks. Read them out, so the export holds
      // the passage rather than a hole where it was.
      if (tag === 'TEXTAREA' || tag === 'INPUT') {
        if (!isComposerEl(node)) {
          var v = String(node.value == null ? '' : node.value).replace(/\s+$/, '');
          v.split(/\n{2,}/).forEach(function (para) { pushText(para.trim()); });
        }
        return;
      }
      var child = node.firstChild;
      while (child) { walk(child); child = child.nextSibling; }
    }
    walk(rootEl);
    if (!out.length) pushText(textOf(rootEl));
    return out;
  }

  // ---------------------------------------------------- finding the messages
  function normText(t) { return (t || '').replace(/\s+/g, ' ').trim(); }
  var textCache = (typeof WeakMap === 'function') ? new WeakMap() : {
    get: function () {}, set: function () {}   // no cache, just slower
  };

  // Where the messages are. Each site is tried in turn, and the first that
  // finds anything wins; the last is a net for markup we have not seen.
  // Does anything about this element say a person wrote it? Used by every
  // strategy below, because the one thing the sites agree on is that the human
  // side is labelled and Claude's side is whatever is left.
  function looksHuman(el) {
    var tid = (el.getAttribute && el.getAttribute('data-testid')) || '';
    if (/user|human/i.test(tid)) return true;
    var cls = (el.className && el.className.indexOf ? el.className : '') + '';
    return /font-user-message|user-message|human-turn/i.test(cls);
  }
  // The same question asked of a turn rather than the labelled element inside
  // it: when the shape-based finder hands back turn wrappers, the label it is
  // looking for is usually one level down.
  function humanish(el) {
    if (looksHuman(el)) return true;
    if (!el.querySelector) return false;
    return !!el.querySelector('[data-testid*="user" i],[data-testid*="human" i],' +
      '[class*="font-user-message"],[class*="user-message"]');
  }
  // chatgpt.com labels every turn for screen readers — "You said:" and
  // "ChatGPT said:" in a hidden heading just before the message — and has done
  // so through every rename of its attributes. A page with none of the named
  // attributes still has these. A label's turn is the highest wrapper that
  // holds this label and no other, when that wrapper holds more than the
  // label. When it does not — the label sits in a wrapper of its own and the
  // message follows as a sibling — the turn is the widest of the siblings
  // between it and the next label. A label with no message is not a turn.
  var SAID_RE = /^(you|chatgpt|assistant|[a-z0-9][a-z0-9 ._-]{0,30}) said:?$/i;
  var LABEL_PREFIX = /^(you|chatgpt|assistant|[a-z0-9][a-z0-9 ._-]{0,30}) said:?\s*/i;
  function unlabel(t) { return (t || '').replace(LABEL_PREFIX, ''); }
  var saidRole = (typeof WeakMap === 'function') ? new WeakMap() : { get: function () {}, set: function () {} };
  function saidHeadings() {
    var out = [], hs = document.querySelectorAll('h1,h2,h3,h4,h5,h6,[class*="sr-only"],[class*="visually-hidden"]');
    for (var i = 0; i < hs.length; i++) {
      var h = hs[i];
      if (host.contains(h)) continue;
      var t = normText(h.textContent);
      if (t.length > 40 || !SAID_RE.test(t)) continue;
      out.push(h);
    }
    return out;
  }
  function turnOfLabel(h, prev, next) {
    var hl = normText(h.textContent).length, A = h, p;
    while ((p = A.parentElement) && p !== document.body && p.tagName !== 'MAIN' &&
           !(prev && p.contains(prev)) && !(next && p.contains(next))) A = p;
    if (normText(A.textContent).length - hl >= BLOCK_MIN) return A;
    var best = null, bestLen = 0;
    for (var sib = A.nextElementSibling; sib && !(next && sib.contains(next)); sib = sib.nextElementSibling) {
      if (host.contains(sib) || (sib.closest && sib.closest(EDITABLE_SEL))) continue;
      var len = normText(sib.textContent).length;
      if (len >= BLOCK_MIN && len > bestLen) { best = sib; bestLen = len; }
    }
    return best;
  }
  function saidTurns() {
    var hs = saidHeadings(), out = [], i;
    for (i = 0; i < hs.length; i++) {
      var h = hs[i], turn = turnOfLabel(h, hs[i - 1], hs[i + 1]);
      if (!turn || turn === h) continue;
      if (turn.closest && turn.closest(EDITABLE_SEL)) continue;
      saidRole.set(turn, /^you\b/i.test(normText(h.textContent)));
      if (out.indexOf(turn) < 0) out.push(turn);
    }
    return out;
  }
  var CHAT_FINDERS = [
    { sel: '[data-message-author-role]',
      user: function (el) { return el.getAttribute('data-message-author-role') === 'user'; } },
    { sel: '"You said:" / "ChatGPT said:" labels', find: saidTurns,
      user: function (el) { return saidRole.get(el) === true; } },
    // Claude's own markup, every spelling of it we have seen. `font-claude-message`
    // became `font-claude-response`, which is exactly the kind of rename that
    // empties an export, so these are matched on a substring rather than whole.
    { sel: '[data-testid="user-message"],[data-testid="assistant-message"],' +
           '[class*="font-user-message"],[class*="font-claude-message"],[class*="font-claude-response"]',
      user: looksHuman },
    // Anything at all that is labelled like a message, plus the container
    // Claude marks while a reply is arriving.
    { sel: 'main [data-testid*="message" i],main [data-is-streaming],' +
           '[data-testid*="message" i],[data-is-streaming]',
      user: looksHuman }
  ];

  // When no name we know of matches, the conversation is still there to be
  // found by its shape: a run of sibling elements, each holding a paragraph's
  // worth of text. The container whose own children hold the most text is the
  // thread — a nav or a sidebar has many children and little in them. This
  // costs a walk of the page, so it runs only when every named strategy has
  // come back empty, which is to say only when the alternative is an empty file.
  var BLOCK_MIN = 24;        // shorter than this, a child is furniture
  function structuralTurns() {
    var root = document.querySelector('main') || document.body;
    if (!root) return [];
    var cands = root.querySelectorAll('div,section,ol,ul,article');
    var best = null, bestChars = 0, bestDepth = -1;
    for (var i = 0; i < cands.length; i++) {
      var el = cands[i];
      if (host.contains(el) || el.contains(host)) continue;
      if (el.closest('nav,aside,header,footer,[role="navigation"]')) continue;
      var kids = el.children;
      if (kids.length < 2) continue;
      var n = 0, chars = 0;
      for (var j = 0; j < kids.length; j++) {
        if (host.contains(kids[j])) continue;
        if (kids[j].closest(EDITABLE_SEL)) continue;     // the composer is not a turn
        var len = (kids[j].textContent || '').trim().length;
        // A child that is mostly a link is a list entry, not a message.
        if (len >= BLOCK_MIN && !kids[j].matches('a') && !kids[j].querySelector('a[href]:only-child')) {
          n++; chars += len;
        }
      }
      if (n < 2 || !chars) continue;
      var depth = 0, up = el;
      while ((up = up.parentElement)) depth++;
      if (chars > bestChars || (chars === bestChars && depth > bestDepth)) {
        best = el; bestChars = chars; bestDepth = depth;
      }
    }
    if (!best) return [];
    var out = [];
    for (var k = 0; k < best.children.length; k++) {
      var c = best.children[k];
      if (host.contains(c) || (c.textContent || '').trim().length < BLOCK_MIN) continue;
      if (c.closest(EDITABLE_SEL)) continue;
      out.push(c);
    }
    return out;
  }

  // The messages the page is rendering right now, in order.
  //
  // The strategies are scored, not tried in turn until one hits. Taking the
  // first that matches anything is what made a Claude export come out half
  // empty: when `font-claude-message` was renamed, the selector naming it
  // alongside `user-message` still matched — just the human's side of the
  // conversation — and a strategy that matches one side does not fail, it
  // silently exports half. So a candidate that sees both sides beats one that
  // sees more turns of a single side, and the shape-based finder competes on
  // the same terms rather than waiting for everything else to come back empty.
  function prune(els) {
    return els.filter(function (el, idx) {
      if (host.contains(el)) return false;
      for (var j = 0; j < els.length; j++) {
        if (j !== idx && els[j].contains(el)) return false;   // outermost only
      }
      return true;
    });
  }
  function score(c) {
    var you = 0, them = 0;
    for (var i = 0; i < c.els.length; i++) (c.user(c.els[i]) ? you++ : them++);
    c.you = you; c.them = them;
    // One message is a conversation that has only been started, and is complete.
    c.whole = (you > 0 && them > 0) || c.els.length === 1;
    return (c.whole ? 1e6 : 0) + c.els.length;
  }
  function liveTurns() {
    var best = null, bestScore = -1, i;
    for (i = 0; i < CHAT_FINDERS.length; i++) {
      var els;
      try {
        els = CHAT_FINDERS[i].find ? CHAT_FINDERS[i].find()
          : Array.prototype.slice.call(document.querySelectorAll(CHAT_FINDERS[i].sel));
      } catch (e) { continue; }
      els = prune(els);
      if (!els.length) continue;
      var c = { els: els, user: CHAT_FINDERS[i].user };
      var sc = score(c);
      if (sc > bestScore) { best = c; bestScore = sc; }
      // A named strategy that sees the whole conversation is the answer, and
      // looking further would only cost a page walk for nothing.
      if (c.whole && els.length > 1) break;
    }
    // Only now, and only because what we have is partial or absent, is the
    // walk of the page worth its cost.
    if (!best || !best.whole) {
      var st = prune(structuralTurns());
      if (st.length) {
        // Prefer a label if there is one anywhere in the turn; fall back to the
        // rhythm only when the page says nothing at all about who spoke, since
        // alternating is a guess and a guess is wrong on a thread where someone
        // sent two messages in a row.
        var anyLabelled = st.some(humanish);
        var sc2 = { els: st, user: function (el) {
          return anyLabelled ? humanish(el) : st.indexOf(el) % 2 === 0;
        } };
        if (score(sc2) > bestScore) best = sc2;
      }
    }
    if (!best || !best.els.length) return [];
    var finder = best;
    return best.els.map(function (el) {
      // innerText is what the page actually shows, which is the whole point —
      // but asking for it forces the browser to lay the page out, and on a
      // long thread that is the one genuinely expensive thing here. So it is
      // asked only when the element's own text has changed, which textContent
      // answers without any layout at all.
      var tl = (el.textContent || '').length, kids = el.childElementCount;
      var seen = textCache.get(el);
      if (!seen || seen.tl !== tl || seen.kids !== kids) {
        var norm = unlabel(normText(el.innerText || ''));
        // `head` comes from innerText because it is what the message looks
        // like, and it is only ever shown to you. It must never be used to
        // recognise a message: innerText is what the page *renders*, so for a
        // message the browser has not laid out — which, in a list that builds
        // only what is on screen, is most of them — it comes back different or
        // empty. `sig` is taken from textContent, which is in the document
        // whether or not anything has been drawn, and so reads the same every
        // time the same message is met.
        var raw = normText(el.textContent || '');
        seen = {
          tl: tl, kids: kids, head: norm.slice(0, 60), len: norm.length,
          // The opening only, and not the length: a message that gets unfolded
          // on the way past has to stay the same message, and unfolding it
          // changes how long it is while leaving how it starts alone. That is
          // what lets the fuller reading replace the folded one in place
          // instead of arriving as a second entry.
          sig: hashOf(raw.slice(0, 140))
        };
        textCache.set(el, seen);
      }
      return {
        el: el,
        role: finder.user(el) ? 'You' : 'Assistant',
        id: (el.getAttribute && (el.getAttribute('data-message-id') || el.getAttribute('data-turn-id'))) || '',
        turnNo: turnNumberOf(el),
        head: seen.head, len: seen.len, sig: seen.sig
      };
    });
  }

  // What names a message across a re-read: not where it sits, since the walk
  // moves everything, and nothing that depends on the message having been
  // drawn. A site id when there is one; otherwise its own text.
  function hashOf(str) {
    var h = 5381, i = str.length;
    while (i) h = (h * 33 ^ str.charCodeAt(--i)) >>> 0;
    return h.toString(36);
  }
  function turnKey(t) {
    return t.id || (t.role + '|' + (t.sig || t.head));
  }
  // ChatGPT numbers its turns — <article data-testid="conversation-turn-N"> —
  // and that number is the one fact about order that no amount of scrolling,
  // loading or re-rendering can disturb. Where it exists it decides the order
  // of the export outright; everything else is a fallback for pages without it.
  function turnNumberOf(el) {
    try {
      var a = el.closest && el.closest('[data-testid^="conversation-turn-"]');
      if (!a) return -1;
      var n = parseInt(a.getAttribute('data-testid').replace('conversation-turn-', ''), 10);
      return isNaN(n) ? -1 : n;
    } catch (e) { return -1; }
  }

  // A message's body, read off the page. Blocks are what the exporters want:
  // paragraphs in prose, lines in a code view.
  function turnBlocks(t) {
    if (t.el && t.el.isConnected) {
      var live = serializeBlocks(t.el);
      // A harvested copy can hold more than the page does now: the message was
      // expanded when it was read and the site has since collapsed it again.
      if (t.b && t.b.join('\n').length > live.join('\n').length) return t.b.slice();
      return live;
    }
    return t.b ? t.b.slice() : [];
  }

  // The conversation as the page is rendering it, which is what an export is.
  // Both sites load a long thread in pieces, so this is the part of it that is
  // on screen — scroll back and open what is collapsed, and it is more.
  function conversationTurns() {
    var live = inReadingOrder(liveTurns());
    if (!live.length) return null;
    return live.map(function (t, i) {
      return { role: t.role, el: t.el, len: t.len, key: turnKey(t) };
    });
  }

  // --------------------------------------------------------------- voice
  // Bring your own.
  //
  // Assay shipped a recogniser for a while, and then fetched one, and neither
  // survived contact with a chat page: the page decides whether a script inside
  // it may reach another origin, and whether it may start the background worker
  // an offline recogniser runs in. Both answers are no, and nothing on our side
  // changes either. Packaging it also meant six megabytes in the extension and
  // a slower review in every store, for a feature that then did not work.
  //
  // So dictation here is whatever you already have. If the browser can
  // recognise speech on the device — Chrome and Edge can — the mic buttons use
  // it, and no language pack is ever downloaded: if one is missing, that is a
  // no rather than a prompt. Everywhere else, including Firefox, the scratchpad
  // is a plain text field and your keyboard's own dictation types into it,
  // which is the same words by a shorter road. Everything else the scratchpad
  // does — selecting, rewording, collecting, putting it in the message box —
  // never needed a recogniser at all.
  // Still worth knowing which of the two Assay is, because it is the first
  // question any report about this raises — it just no longer changes what
  // dictation does.
  var IN_EXTENSION = (function () {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) return true;
      if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.id) return true;
    } catch (e) {}
    return false;
  })();
  var VOICE_KEY = 'assay.voice.v1';
  function voiceCtor() { return window.SpeechRecognition || window.webkitSpeechRecognition; }
  function voiceLang() {
    return loadJSON(VOICE_KEY, {}).lang || (navigator.language || 'en-US');
  }
  // Only ever 'available' or not. There is no downloading state to wait on
  // because nothing is ever asked to download.
  function voiceStatus(cb) {
    var C = voiceCtor();
    if (!C) return cb('nosupport');
    if (!C.available) return cb('nolocal');
    try {
      var r = C.available({ langs: [voiceLang()], processLocally: true });
      if (r && r.then) r.then(function (v) { cb(v || 'unavailable'); }, function () { cb('unavailable'); });
      else cb(r || 'unavailable');
    } catch (e) { cb('unavailable'); }
  }
  function voiceErrorText(code) {
    if (code === 'not-allowed' || code === 'service-not-allowed') {
      return 'The microphone is blocked. Allow it for this site and try again.';
    }
    if (code === 'no-speech') return 'Heard nothing.';
    if (code === 'audio-capture') return 'No microphone was found.';
    if (code === 'language-not-supported') return 'This language is not available on the device.';
    if (code === 'network') return 'That needed the network, so it was stopped.';
    return 'Dictation stopped.';
  }

  var rec = null, recOn = false;
  function listening() { return recOn; }
  function stopListening() {
    recOn = false;
    if (!rec) return;
    try { rec.onend = null; rec.onresult = null; rec.onerror = null; rec.stop(); } catch (e) {}
    rec = null;
  }
  function startListening(h) {
    var C = voiceCtor();
    if (!C) { h.error('This browser cannot do speech recognition.'); return; }
    stopListening();
    rec = new C();
    rec.lang = voiceLang();
    rec.continuous = true;
    rec.interimResults = true;
    // Never quietly send a microphone to a server.
    try { rec.processLocally = true; } catch (e) {}
    rec.onresult = function (e) {
      var interim = '', fin = '';
      for (var i = e.resultIndex; i < e.results.length; i++) {
        var r = e.results[i];
        if (r.isFinal) fin += r[0].transcript;
        else interim += r[0].transcript;
      }
      if (fin) h.final(fin);
      h.interim(interim);
    };
    rec.onerror = function (e) {
      recOn = false;
      h.error(voiceErrorText(e && e.error));
    };
    rec.onend = function () { recOn = false; if (h.end) h.end(); };
    recOn = true;
    try { rec.start(); } catch (e) { recOn = false; h.error('Could not start listening.'); }
  }

  // The one place that decides whether the mic button does anything. A refusal
  // is final and says what to do instead — there is nothing to offer to fetch.
  var KEYBOARD_HINT = ' Your keyboard\'s own dictation types into the scratchpad, which works everywhere.';
  function withVoice(onReady, onRefuse) {
    voiceStatus(function (st) {
      if (st === 'available') return onReady();
      if (st === 'nosupport') {
        return onRefuse('This browser has no speech recognition of its own.' + KEYBOARD_HINT, false);
      }
      if (st === 'nolocal') {
        return onRefuse('This browser can only recognise speech by sending it to a server, so Assay will not use it.' +
          KEYBOARD_HINT, false);
      }
      if (st === 'downloadable' || st === 'downloading') {
        return onRefuse('This browser could recognise ' + voiceLang() + ' on the device, but the language pack is ' +
          'not installed and Assay does not download things.' + KEYBOARD_HINT, false);
      }
      onRefuse('Speech recognition is not available on this device for ' + voiceLang() + '.' + KEYBOARD_HINT, false);
    });
  }

  // ------------------------------------------------- harvesting the whole thing
  // Neither site keeps a long conversation in the page. Older messages are only
  // built when you scroll back to them, and long ones stay folded behind "show
  // more" until asked — so what an export can see is a window, and the rest of
  // the thread does not exist as far as the document is concerned.
  //
  // Assay used to answer that by remembering messages as they went past, in
  // storage, all the time. That cost the thing the product is for: watching the
  // page made selection lag. This is the other answer, and the honest one. It
  // does the work once, when you ask for it, in front of you: it walks the
  // thread to the top, opens what is folded, reads each window on the way back
  // down, and stitches them. It blocks — there is a progress line and a Stop —
  // and when it ends nothing is left running and nothing is left stored.
  function scrollerFor(el) {
    var n = el;
    while (n && n !== document.body && n !== document.documentElement) {
      var o = '';
      try { o = getComputedStyle(n).overflowY; } catch (e) {}
      if ((o === 'auto' || o === 'scroll' || o === 'overlay') && n.scrollHeight > n.clientHeight + 40) return n;
      n = n.parentElement;
    }
    var de = document.scrollingElement || document.documentElement;
    return (de && de.scrollHeight > de.clientHeight + 40) ? de : null;
  }

  // Opening what the site folded. Only inside a message, only controls that
  // say they unfold something, and never anything that could send, delete or
  // navigate — a harvest that posts a message would be unforgivable.
  var EXPAND_RE = /\b(show|see|read|view)\s+(more|all|full|original|the rest)\b|\bcontinue reading\b|\bexpand\b|\bshow full\b/i;
  // Viewers are not folds. "Expand table" on chatgpt.com opens the table in a
  // dialog over the thread — the rows were in the message all along — and the
  // dialog locks the thread's scroll, so a walk that opened one stopped there.
  var EXPAND_NEVER = /\b(send|submit|delete|remove|retry|regenerate|stop|share|copy|edit|branch|fork|report|sign|log ?out|upgrade|table|image|chart|code|canvas|diagram|artifact|preview|full ?screen|zoom|enlarge|download|open in)\b/i;
  function dialogsOpen() {
    var n = 0, ds = document.querySelectorAll('[role="dialog"],dialog[open]');
    for (var i = 0; i < ds.length; i++) if (!host.contains(ds[i])) n++;
    return n;
  }
  // A click that opened a dialog opened something that was not a fold; close
  // it, or the walk reads a locked thread.
  function closeDialog() {
    var ds = document.querySelectorAll('[role="dialog"],dialog[open]'), i, j;
    for (i = 0; i < ds.length; i++) {
      if (host.contains(ds[i])) continue;
      var btns = ds[i].querySelectorAll('button,[role="button"]');
      for (j = 0; j < btns.length; j++) {
        var l = ((btns[j].getAttribute('aria-label') || '') + ' ' + (btns[j].textContent || '')).trim();
        if (/^(close|dismiss|done|×|✕|✖)$/i.test(l) || /\b(close|dismiss)\b/i.test(l)) { try { btns[j].click(); } catch (e) {} break; }
      }
    }
    try {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
      document.dispatchEvent(new KeyboardEvent('keyup', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    } catch (e) {}
  }
  var dialogsClosed = 0;
  function expandOnce() {
    var opened = 0, turns = liveTurns(), i, j, before = dialogsOpen();
    for (i = 0; i < turns.length; i++) {
      var el = turns[i].el;
      // <details> opens without a click, which is the safest way to open it.
      var dets = el.querySelectorAll('details:not([open])');
      for (j = 0; j < dets.length; j++) { dets[j].open = true; opened++; }
      var btns = el.querySelectorAll('button,[role="button"],summary');
      for (j = 0; j < btns.length; j++) {
        var b = btns[j];
        if (host.contains(b) || b.getAttribute('data-assay-exp')) continue;
        // Not `b.type === 'submit'`: a bare <button> reports "submit" whether or
        // not it is in a form, and that quietly rejected every "Show more"
        // there is. What matters is whether there is a form for it to submit.
        if (b.closest('form')) continue;
        var label = ((b.innerText || b.textContent || '') + ' ' +
          (b.getAttribute('aria-label') || '') + ' ' + (b.getAttribute('title') || '')).trim();
        if (label.length > 40) continue;               // a paragraph is not a control
        if (b.tagName !== 'SUMMARY' && !EXPAND_RE.test(label)) continue;
        if (EXPAND_NEVER.test(label)) continue;
        b.setAttribute('data-assay-exp', '1');         // once each, whatever happens
        try { b.click(); opened++; } catch (e) {}
        if (dialogsOpen() > before) { closeDialog(); dialogsClosed++; opened--; }
      }
    }
    return opened;
  }

  // One window of the thread, with its text taken now — the element will be
  // gone from the page by the time the walk reaches the bottom.
  // The order a conversation is read in. A list that builds only what is on
  // screen recycles its rows, so their order in the document is whatever the
  // page last did with them and has nothing to do with the conversation. Where
  // a message sits on the page does. This costs a layout, so it is asked only
  // where order is the thing being decided — never on a tap.
  function inReadingOrder(turns) {
    var withY = turns.map(function (t, i) {
      var y = i;
      try { y = t.el.getBoundingClientRect().top; } catch (e) {}
      return { t: t, y: y, i: i };
    });
    withY.sort(function (a, b) { return a.y - b.y || a.i - b.i; });
    return withY.map(function (w) { w.t.y = w.y; return w.t; });
  }
  function windowTurns() {
    var list = inReadingOrder(liveTurns());
    return list.map(function (t, i) {
      return {
        role: t.role, el: t.el, id: t.id, turnNo: t.turnNo, head: t.head, len: t.len, y: t.y,
        b: serializeBlocks(t.el), key: turnKey(t),
        // A message with no id of its own is told apart from an identical one
        // elsewhere by what comes before it: the second "Yes." in a thread has
        // a different neighbour from the first. The first message in a window
        // has no neighbour in view, which absorb allows for.
        base: turnKey(t),
        prev: i > 0 ? turnKey(list[i - 1]) : null
      };
    });
  }
  // Putting the windows together.
  //
  // One slot per message, full stop. Earlier versions allowed a key to appear
  // twice if it appeared twice within one window, to keep two identical
  // messages apart — and a page that momentarily holds two copies of a row
  // while it re-renders turned that into a permanent duplicate. Identical
  // messages are told apart by their neighbour now (see windowTurns), so the
  // rule here can be the simple one.
  function absorb(acc, win, at) {
    at.byQual = at.byQual || {};
    at.byBase = at.byBase || {};
    function fuller(idx, t) {
      var held = acc[idx];
      // The same message, read again with more of it showing.
      if ((t.b || []).join('\n').length > (held.b || []).join('\n').length) {
        t.prev = t.prev || held.prev;
        acc[idx] = t;
      }
    }
    function add(t) {
      var idx = acc.length;
      acc.push(t);
      (at.byBase[t.base] = at.byBase[t.base] || []).push(idx);
      if (t.prev !== null) at.byQual[t.base + '<' + t.prev] = idx;
      return idx;
    }
    for (var i = 0; i < win.length; i++) {
      var t = win[i];
      if (t.id) {
        // An id settles it. Nothing about neighbours applies.
        if (at[t.id] === undefined) at[t.id] = add(t); else fuller(at[t.id], t);
        continue;
      }
      var known = at.byBase[t.base] || [];
      if (t.prev !== null) {
        var q = t.base + '<' + t.prev;
        if (at.byQual[q] !== undefined) { fuller(at.byQual[q], t); continue; }
        // Held already, but first met at the top of a window where its
        // neighbour was out of view: this is that message, now with context.
        var orphan = -1;
        for (var k = 0; k < known.length; k++) if (acc[known[k]].prev === null) { orphan = known[k]; }
        if (orphan >= 0) { acc[orphan].prev = t.prev; at.byQual[q] = orphan; fuller(orphan, t); continue; }
        add(t);
      } else {
        // Top of a window, neighbour out of view. If a message that reads
        // like this is already held, it is that one — the most recent of them,
        // since the walk goes downward and this sits just after what was read
        // last. Only a message never seen before starts a new entry.
        if (known.length) { fuller(known[known.length - 1], t); continue; }
        add(t);
      }
    }
    return acc;
  }

  // The order of the export. Where the page numbers its turns, that number is
  // the order and nothing about how the walk went can change it. Where it does
  // not, the order is the order the capture pass met them in — and the capture
  // pass only counts if the document held still for the whole of it.
  function finish(acc) {
    var numbered = acc.length > 0;
    for (var i = 0; i < acc.length; i++) if (!(acc[i].turnNo >= 0)) { numbered = false; break; }
    if (numbered) {
      acc = acc.map(function (t, i) { return { t: t, i: i }; })
        .sort(function (a, b) { return (a.t.turnNo - b.t.turnNo) || (a.i - b.i); })
        .map(function (w) { return w.t; });
    }
    // Belt and braces: an id can appear once, whatever else happened.
    var seen = {}, out = [];
    for (var j = 0; j < acc.length; j++) {
      var id = acc[j].id;
      if (id) { if (seen[id]) continue; seen[id] = true; }
      out.push(acc[j]);
    }
    return out;
  }

  var HARVEST_MS = 150000;       // a ceiling, so a strange page cannot hang here
  var QUIET_MS = 2500;           // how long the top has to hold still to count as the top
  var harvestStop = false;
  var lastWalk = null;           // what the last walk saw, for the diagnosis
  function harvest(onProgress) {
    return new Promise(function (resolve) {
      var first = liveTurns()[0];
      if (!first) return resolve([]);
      var sc = scrollerFor(first.el);
      if (!sc) return resolve(finish(windowTurns()));   // nothing scrolls; this is all of it
      var began = Date.now(), startTop = sc.scrollTop;
      var walk = { top: [], windows: [], passes: 0, stopped: false, dialogs: 0 };
      dialogsClosed = 0;
      lastWalk = walk;
      function spent() { return harvestStop || Date.now() - began > HARVEST_MS; }
      function step() { return Math.max(120, sc.clientHeight * 0.7); }
      // What the top of the document looks like: which turns are built while
      // the scroll sits at zero. Not how tall the page is, which changes as
      // images load and folds open, and not the first turn alone: chatgpt.com
      // keeps the first turn in the document at every scroll position, so by
      // that measure the top had "settled" before a single older message had
      // arrived, and the walk missed a third of a long thread.
      function snapshot() {
        return inReadingOrder(liveTurns()).map(function (t) {
          return t.turnNo >= 0 ? t.turnNo : turnKey(t);
        }).join(',');
      }
      function label(t) { return t.turnNo >= 0 ? t.turnNo : (t.id || t.head.slice(0, 12)); }
      function finishWith(acc) {
        walk.stopped = harvestStop;
        walk.dialogs = dialogsClosed;
        var out = finish(acc);
        // The trace records what the export is, not what the walk held before
        // it was put in order — the two differed, and the trace was read as
        // the export.
        walk.final = out.map(label);
        sc.scrollTop = startTop;                     // put the page back where it was
        resolve(out);
      }
      // On a page that numbers its turns and keeps the last of them in view at
      // every scroll position — as chatgpt.com does — the number of the final
      // turn is known from the first window, and the walk is done the moment
      // every number from the first to it is held. The rest of the scroll would
      // only read the same pinned tail eighty more times.
      function complete(acc) {
        if (!acc.length) return false;
        var lo = Infinity, hi = -Infinity, seen = {};
        for (var i = 0; i < acc.length; i++) {
          var n = acc[i].turnNo;
          if (!(n >= 0)) return false;
          if (n < lo) lo = n;
          if (n > hi) hi = n;
          seen[n] = true;
        }
        for (var k = lo; k <= hi; k++) if (!seen[k]) return false;
        return hi - lo + 1 === acc.length;
      }

      // 1. The top. Not "unchanged twice" — a batch of older messages is a
      // network round trip, and on a phone that is easily longer than two
      // polls — but "nothing has changed for a good while". The scroll is
      // nudged off zero and back between polls, since some pages load the next
      // batch only on a fresh crossing of the top.
      var quiet = 0, last = '';
      function up(nudge) {
        if (spent()) return expandDown(0);
        sc.scrollTop = nudge ? 40 : 0;
        setTimeout(function () {
          sc.scrollTop = 0;
          setTimeout(function () {
            var snap = snapshot();
            if (sc.scrollTop <= 2 && snap === last) quiet += 500; else quiet = 0;
            last = snap;
            walk.top.push(snap);
            onProgress('Finding the start of the conversation…', liveTurns().length);
            if (quiet >= QUIET_MS) return expandDown(0);
            up(!nudge);
          }, 400);
        }, 100);
      }

      // 2. Open everything folded, top to bottom. Nothing is read on this
      // pass: opening a message changes its text, and identity must never be
      // taken from text that is still changing.
      function expandDown(pos) {
        sc.scrollTop = pos;
        setTimeout(function () {
          var opened = 0;
          try { opened = expandOnce(); } catch (e) {}
          onProgress('Opening folded messages…', liveTurns().length);
          var bottom = sc.scrollHeight - sc.clientHeight;
          if (spent() || pos >= bottom - 2) return capture(0);
          setTimeout(function () { expandDown(Math.min(bottom, pos + step())); }, opened ? 300 : 0);
        }, 200);
      }

      // 3. Read, top to bottom, over a document that is holding still. If the
      // top changed while we read — more of the thread arrived — what we read
      // is in an order that no longer means anything, so it is read again.
      function capture(attempt) {
        var acc = [], at = {}, before = null;
        walk.passes++;
        function at_(pos) {
          sc.scrollTop = pos;
          setTimeout(function () {
            // The top is remembered as it looks from the top, once the scroll
            // has settled there — not as it looked from wherever the opening
            // pass left off, which on a page that builds only what is near
            // the screen is a different set of turns every time.
            if (before === null) before = snapshot();
            var win = windowTurns();
            walk.windows.push(win.map(label));
            acc = absorb(acc, win, at);
            onProgress('Reading the conversation…', acc.length);
            var bottom = sc.scrollHeight - sc.clientHeight;
            // Every numbered turn from first to last is held: one look at the
            // very bottom, to be sure nothing sits past the last number, and
            // then done.
            if (complete(acc) && pos < bottom - 2 && !walk.tailChecked) {
              walk.tailChecked = true;
              return at_(bottom);
            }
            if (spent() || pos >= bottom - 2) {
              sc.scrollTop = 0;
              setTimeout(function () {
                if (!spent() && snapshot() !== before && attempt < 2) return capture(attempt + 1);
                finishWith(acc);
              }, 300);
              return;
            }
            at_(Math.min(bottom, pos + step()));
          }, 180);
        }
        at_(0);
      }
      up(false);
    });
  }

  function getConversation() {
    if (IS_GITHUB) {
      // A gist can hold several files, each its own labeled section; a
      // github.com blob page (or a one-file gist with no distinguishing
      // name to find) is still the single path it always was.
      var els = document.querySelectorAll(GH_CONTENT);
      if (!els.length) return null;
      var path = decodeURIComponent(location.pathname.replace(/^\/|\/$/g, ''));
      var multi = els.length > 1;
      return Array.prototype.map.call(els, function (el, i) {
        var fileEl = el.closest('.file');
        var nameEl = fileEl && fileEl.querySelector('.gist-blob-name');
        var name = nameEl && textOf(nameEl).trim();
        var role = name || (multi ? path + ' — message ' + (i + 1) : path) || 'File';
        return { role: role, el: el, key: i + ':' + role };
      });
    }
    return conversationTurns();
  }

  function convoTitle() {
    // "Assay/README.md at master · puj/Assay · GitHub" → "Assay/README.md at master"
    if (IS_GITHUB) return ((document.title || '').split(' · ')[0] || '').trim() || 'File';
    var t = (document.title || '').replace(/\s*[—|–-]\s*(ChatGPT|Claude).*$/i, '').trim();
    // A brand-new chat is titled just "ChatGPT"/"Claude" — not a real title.
    if (/^(chatgpt|claude|new chat)$/i.test(t)) t = '';
    return t || 'Conversation';
  }

  // Filenames read brand → chat title → timestamp, so exports group by app,
  // say what they are, and sort chronologically within one conversation.
  function titleSlug() {
    var t = convoTitle();
    if (t === 'Conversation') return '';
    return t
      .replace(/[\u0000-\u001F\/\\?%*:|"'<>.,;#&$!`]+/g, ' ')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 60)
      .replace(/-+$/, '');
  }

  function fragmentAppendixMd(lines) {
    lines.push('---', '', '## Collected fragments (' + fragments.length + ')', '');
    fragments.forEach(function (f, i) {
      var note = (f.note || '').trim();
      var lead = leadClause(f);
      lines.push('### ' + (i + 1), '');
      if (lead) lines.push('*' + lead + ':*', '');
      fragText(f).split('\n').forEach(function (l) { lines.push('> ' + l); });
      if (note && f.notePos !== 'pre') lines.push('', '→ *' + note + '*');
      lines.push('');
    });
  }

  function buildConversationMarkdown(turns, scope) {
    if (!turns && !fragments.length) return null;
    var lines = ['# ' + convoTitle(), '',
      '_' + location.hostname + ' — ' + niceStamp() + (scope ? ' — ' + scope : '') + '_', ''];
    if (turns) {
      turns.forEach(function (t) {
        lines.push('## ' + t.role, '');
        turnBlocks(t).forEach(function (b) { lines.push(b, ''); });
      });
    }
    if (fragments.length) fragmentAppendixMd(lines);
    return lines.join('\n');
  }

  function buildConversationText(turns, scope) {
    if (!turns && !fragments.length) return null;
    var parts = [convoTitle() + ' — ' + location.hostname + ' — ' + niceStamp() + (scope ? ' — ' + scope : '')];
    if (turns) {
      turns.forEach(function (t) {
        parts.push(t.role + ':\n' + turnBlocks(t).join('\n\n'));
      });
    }
    if (fragments.length) {
      parts.push('--- Collected fragments ---\n\n' + buildPayload());
    }
    return parts.join('\n\n') + '\n';
  }

  function download(name, text, mime) {
    try {
      var blob = new Blob([text], { type: mime });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = name;
      (document.body || document.documentElement).appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
      return true;
    } catch (e) {
      return false;
    }
  }

  // ------------------------------------------------------- choosing messages
  // Most of the time what you want is the last few exchanges, not thirty. The
  // picker lists the conversation with who said what and enough of each
  // message to recognise it, and ↓ takes one message and everything after —
  // which is that common case in a single tap.
  var picker = $('picker'), pickList = $('pickList');
  var pickTurns = [], picked = [], pickExt = 'md', pickMime = 'text/markdown';
  var pickOpen = {};   // which messages are opened to show what was captured

  function turnText(t) {
    return turnBlocks(t).join('\n\n');
  }
  function pickPreview(text) {
    return (text || '').replace(/\s+/g, ' ').trim().slice(0, 160);
  }
  // Enough of a message to recognise it, and how much of it we hold — read
  // without once asking the browser for laid-out text. innerText forces a
  // layout, and this list runs to as many rows as the thread is long, so the
  // message itself is fetched only for the row you open.
  function turnHint(t) {
    var src = (t.el && t.el.isConnected) ? normText(t.el.textContent || '') : '';
    var held = t.b ? t.b.join('\n\n') : '';
    if (held.length > src.length) src = held;
    return { len: src.length, prev: pickPreview(src.slice(0, 600)), off: !(t.el && t.el.isConnected) };
  }
  function countLabel(n) {
    return n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1) + 'k characters' : n + ' characters';
  }

  // "messages 19–30 of 30" when the choice is a run, a plain count when it is
  // not, and nothing at all when the file holds everything.
  function pickScope() {
    var total = pickTurns.length, on = [];
    picked.forEach(function (v, i) { if (v) on.push(i); });
    if (!on.length || on.length === total) return '';
    var run = on[on.length - 1] - on[0] + 1 === on.length;
    return run
      ? 'messages ' + (on[0] + 1) + '–' + (on[on.length - 1] + 1) + ' of ' + total
      : on.length + ' of ' + total + ' messages';
  }

  function paintPickHeader() {
    var n = picked.filter(Boolean).length;
    $('pickTitle').textContent = n === pickTurns.length
      ? 'All ' + n + ' messages'
      : n + ' of ' + pickTurns.length + ' messages';
    var hint = $('pickHint');
    if (!pickTurns.length) {
      hint.textContent = 'No messages found on this page.';
      return;
    }
    // Both sites load a long thread in pieces, so this list is only as long as
    // the page has made it. Saying so, and saying what to do about it, is
    // better than quietly exporting less than you asked for.
    // Two different arrows live in this sheet, so neither is named by its
    // shape: one is a button you press, the other is on every row.
    hint.textContent = IS_GITHUB
      ? 'Tap ↓ to take this and everything after it, or a size to read it.'
      : 'This is what the page has loaded so far. Tap ↓ on a message to take it and ' +
        'everything after, or a size to read it.';
    $('pickGo').disabled = !n && !fragments.length;
    $('pickGo').innerHTML = '&#x2B07; Download .' + pickExt;
  }

  // One row, built once and then kept. The list is redrawn every time a scroll
  // picks more of the thread up, and throwing away a few hundred rows to build
  // a few hundred identical ones is the difference between the list keeping up
  // and the page stuttering — so rows are made when their message first
  // appears, updated in place after that, and moved rather than remade when
  // the order changes. Handlers read the row's position off the element, since
  // that position is exactly what moves.
  var pickRows = {};
  function buildRow(key) {
    var wrap = document.createElement('div');
    wrap.className = 'pick';
    var row = document.createElement('div');
    row.className = 'row';
    row.setAttribute('role', 'button');
    var tick = document.createElement('span');
    tick.className = 'tick';
    tick.textContent = '\u2713';
    var body = document.createElement('span');
    body.className = 'body';
    var who = document.createElement('span');
    who.className = 'who';
    var prev = document.createElement('span');
    prev.className = 'prev';
    body.appendChild(who); body.appendChild(prev);

    // How much of this message we actually hold, and where it came from —
    // the whole point of the memory is that you can check it.
    var meta = document.createElement('button');
    meta.className = 'meta';
    meta.title = 'Show what was captured';
    var full = document.createElement('pre');
    full.className = 'full';
    full.hidden = true;
    var at = function () { return +wrap.getAttribute('data-i'); };
    meta.addEventListener('click', function (e) {
      e.stopPropagation();
      var open = full.hidden;
      if (open && !full.textContent) {
        full.textContent = turnText(pickTurns[at()]) || '(nothing captured)';
      }
      full.hidden = !open;
      meta.classList.toggle('open', open);
      pickOpen[key] = open;
    });
    body.appendChild(meta);
    body.appendChild(full);
    row.appendChild(tick); row.appendChild(body);
    row.addEventListener('click', function () {
      var i = at();
      picked[i] = !picked[i];
      row.classList.toggle('on', picked[i]);
      paintPickHeader();
    });
    var from = document.createElement('button');
    from.className = 'from';
    from.textContent = '\u2193';
    from.title = 'This message and everything after it';
    from.addEventListener('click', function () {
      var i = at();
      picked = pickTurns.map(function (_, k) { return k >= i; });
      renderPicks();
      paintPickHeader();
    });
    wrap.appendChild(row); wrap.appendChild(from);
    return { wrap: wrap, row: row, who: who, prev: prev, meta: meta, full: full, sig: '' };
  }

  function renderPicks() {
    var seen = {}, node = pickList.firstChild;
    pickTurns.forEach(function (t, i) {
      // A row is identified by where it sits, not by what it says. Two messages
      // that read the same are two messages, and keying rows by their text made
      // the second quietly replace the first — a thread with "Yes." in it twice
      // lost one of them between the harvest and the list.
      var key = i + ':' + (t.key || t.role);
      var r = pickRows[key] || (pickRows[key] = buildRow(key));
      seen[key] = true;
      var hint = turnHint(t);
      var sig = hint.len + ':' + (t.el === null ? 'r' : 's') + ':' + t.role + ':' + hint.prev;
      if (sig !== r.sig) {
        r.sig = sig;
        r.who.textContent = t.role === 'You' ? 'You' : (t.role === 'Assistant' ? BRAND : t.role);
        r.prev.textContent = hint.prev || '(no text)';
        r.meta.textContent = countLabel(hint.len) + (hint.off ? ' · scrolled away' : '');
        // The text it holds is the old copy of a message that has since grown.
        if (!r.full.hidden) r.full.textContent = turnText(t) || '(nothing captured)';
        else r.full.textContent = '';
      }
      var open = !!pickOpen[key];
      if (open && !r.full.textContent) r.full.textContent = turnText(t) || '(nothing captured)';
      if (r.full.hidden === open) {
        r.full.hidden = !open;
        r.meta.classList.toggle('open', open);
      }
      if (r.row.classList.contains('on') !== !!picked[i]) r.row.classList.toggle('on', !!picked[i]);
      r.wrap.setAttribute('data-i', String(i));
      r.row.setAttribute('data-i', String(i));
      if (node === r.wrap) node = node.nextSibling;
      else pickList.insertBefore(r.wrap, node);   // moves it if it is already in
    });
    while (node) { var next = node.nextSibling; pickList.removeChild(node); node = next; }
    Object.keys(pickRows).forEach(function (k) { if (!seen[k]) delete pickRows[k]; });
    paintPickHeader();
  }

  function setLast(n) {
    picked = pickTurns.map(function (_, i) { return i >= pickTurns.length - n; });
    renderPicks();
  }
  $('cogBtn').addEventListener('click', function () {
    $('settingsRow').classList.toggle('off');
  });
  function paintFlatBtn() {
    $('flatBtn').textContent = flatCards ? 'Cards: text' : 'Cards: editable';
    $('compactBtn').textContent = compactPill ? 'Button: compact' : 'Button: full';
  }
  $('compactBtn').addEventListener('click', function () {
    compactPill = !compactPill;
    savePill();
    paintFlatBtn();
    updatePill();
    toast(compactPill ? 'Small round button — drag it anywhere' : 'Full Assay button — drag it anywhere', 2200);
  });
  $('flatBtn').addEventListener('click', function () {
    flatCards = !flatCards;
    saveMap(FLAT_KEY, { on: flatCards });
    if (flatCards) { flattenCards(); toast('Cards read as text — tap to select in them', 2400); }
    else { unflattenCards(); toast('Cards left editable, as the site made them', 2400); }
    paintFlatBtn();
  });

  // No console on a phone, so the page's own answer has to be copyable. This is
  // what Assay can see here, in the shape a bug report needs.
  $('diagBtn').addEventListener('click', function () {
    var lines = ['Assay ' + VERSION + ' on ' + location.hostname];
    try {
      var f = window.__assay._find();
      lines.push('running as: ' + f.runtime);
      lines.push('voice: recogniser=' + f.voice.ctor + ' onDeviceApi=' + f.voice.onDeviceApi +
        ' lang=' + f.voice.lang);
      if (f.walk) {
        lines.push('last walk: ' + f.walk.passes + ' pass(es), ' + f.walk.windows + ' windows' +
          (f.walk.stopped ? ', stopped' : ''));
        lines.push('  top settled on: ' + f.walk.top.join(' / '));
        lines.push('  first windows: ' + JSON.stringify(f.walk.first3));
        lines.push('  last windows: ' + JSON.stringify(f.walk.last2));
        lines.push('  final order: ' + JSON.stringify(f.walk.final));
      }
      f.strategies.forEach(function (st, i) { lines.push('finder ' + (i + 1) + ': ' + st.n + '  ' + st.sel.slice(0, 60)); });
      lines.push('by shape: ' + f.structural + ' | used: ' + f.found + ' | roles: ' + (f.roles || []).join(','));
      if (f.census) {
        lines.push('census: ' + Object.keys(f.census).filter(function (k) { return typeof f.census[k] === 'number'; })
          .map(function (k) { return k + '=' + f.census[k]; }).join(' '));
        if (f.census.labels) lines.push('  labels: ' + f.census.labels.join(' | '));
        if (f.census.testids) lines.push('  testids: ' + f.census.testids.join(' '));
        (f.census.labelTurns || []).forEach(function (lt) {
          lines.push('  label: ' + lt.label);
          lines.push('    turn: ' + lt.turn);
        });
        if (f.census.markdownPath) lines.push('  first markdown: ' + f.census.markdownPath);
      }
      if (f.sample && f.sample.length) lines.push('page shape: ' + f.sample.join('  '));
      lines.push('cards: ' + (flatCards ? 'text' : 'editable'));
      window.__assay._editables().forEach(function (e) {
        lines.push('editable ' + e.tag + (e.id ? '#' + e.id : '') + (e.testid ? '[' + e.testid + ']' : '') +
          ' .' + e.cls + ' composer=' + e.composer + ' inThread=' + e.inConversation +
          ' selectable=' + e.selectable + ' "' + e.text + '"');
      });
    } catch (err) { lines.push('diagnosis failed: ' + err.message); }
    var report = lines.join('\n');
    copyText(report).then(function (ok) {
      if (ok) toast('Diagnosis copied — paste it into a bug report', 2600);
      else manualCopy(report);
    });
  });

  // The one deliberate, blocking action: walk the thread and take all of it.
  // Everything you had chosen survives it, because what you chose is a message
  // and the messages are still the same messages afterwards.
  var harvesting = false;
  function setScan(on, msg) {
    $('scan').classList.toggle('show', !!on);
    if (msg) $('scanMsg').textContent = msg;
    $('fullRow').classList.toggle('off', !!on);
    $('pickGo').disabled = !!on;
  }
  function askFull(on) {
    $('askFull').classList.toggle('show', !!on);
    $('fullRow').classList.toggle('off', !!on);
  }
  $('scanStop').addEventListener('click', function () { harvestStop = true; $('scanMsg').textContent = 'Stopping…'; });
  // It moves the page around for several seconds, so it asks first. One tap
  // should not start something you have to sit and watch.
  $('pickFull').addEventListener('click', function () { if (!harvesting && !IS_GITHUB) askFull(true); });
  $('fullNo').addEventListener('click', function () { askFull(false); });
  $('fullYes').addEventListener('click', function () {
    if (harvesting || IS_GITHUB) return;
    askFull(false);
    harvesting = true;
    harvestStop = false;
    var was = {};
    pickTurns.forEach(function (t, i) { was[t.key] = picked[i]; });
    setScan(true, 'Reading the conversation…');
    harvest(function (msg, n) {
      $('scanMsg').textContent = msg + (n ? '  ' + n + ' message' + (n === 1 ? '' : 's') : '');
    }).then(function (turns) {
      harvesting = false;
      setScan(false);
      if (!turns || !turns.length) { toast('Found nothing to read on this page'); return; }
      var before = pickTurns.length;
      pickTurns = turns;
      picked = turns.map(function (t) { return was[t.key] === undefined ? true : was[t.key]; });
      pickOpen = {};
      renderPicks();
      pickList.scrollTop = pickList.scrollHeight;
      var gained = turns.length - before;
      // Say what the walk can vouch for. On a page that numbers its turns the
      // numbers should run without a gap; a gap is a message the page never
      // built, and that is worth knowing before the file is written.
      var numbered = turns.every(function (t) { return t.turnNo >= 0; }), gaps = 0;
      if (numbered) {
        for (var i = 1; i < turns.length; i++) if (turns[i].turnNo > turns[i - 1].turnNo + 1) gaps++;
      }
      var vouch = numbered ? (gaps ? ', ' + gaps + ' gap' + (gaps === 1 ? '' : 's') + ' the page never loaded' : ', in order, none repeated') : '';
      toast(harvestStop
        ? 'Stopped — ' + turns.length + ' messages'
        : (gained > 0 ? 'Found ' + gained + ' more — ' + turns.length + ' messages' + vouch
                      : 'That was already all of it — ' + turns.length + ' messages' + vouch), 3200);
    }, function () {
      harvesting = false;
      setScan(false);
      toast('Could not read the whole conversation');
    });
  });

  $('pickAll').addEventListener('click', function () { setLast(pickTurns.length); });
  $('pickNone').addEventListener('click', function () { setLast(0); });
  $('pickLast2').addEventListener('click', function () { setLast(2); });
  $('pickLast6').addEventListener('click', function () { setLast(6); });

  function openPicker(turns, ext, mime) {
    hideChip();
    $('fullRow').classList.toggle('off', IS_GITHUB);   // a file is not a thread to walk
    askFull(false);
    setScan(false);
    clearPending();
    pickTurns = turns;
    pickExt = ext;
    pickMime = mime;
    pickOpen = {};
    picked = turns.map(function () { return true; });
    closeSheet();
    picker.classList.add('show');
    updatePill();
    renderPicks();
    // The recent end is what you came for, so start there.
    pickList.scrollTop = pickList.scrollHeight;
  }
  function closePicker(reopen) {
    picker.classList.remove('show');
    if (reopen) openSheet(); else updatePill();
  }
  $('pickClose').addEventListener('click', function () { closePicker(true); });
  $('pickGo').addEventListener('click', function () {
    var chosen = pickTurns.filter(function (_, i) { return picked[i]; });
    saveExport(chosen.length ? chosen : null, pickScope(), pickExt, pickMime);
    closePicker(false);
  });

  function saveExport(turns, scope, ext, mime) {
    var content = ext === 'md' ? buildConversationMarkdown(turns, scope) : buildConversationText(turns, scope);
    if (!content) { toast('Nothing to export yet'); return; }
    var slug = titleSlug();
    var name = 'assay-' + (slug ? slug + '-' : '') + fileStamp() + '.' + ext;
    if (!download(name, content, mime)) { toast('Download blocked by the browser'); return; }
    toast(turns
      ? 'Saved ' + (scope || 'conversation') + (fragments.length ? ' + fragments' : '') + ' (.' + ext + ')'
      : (IS_GITHUB ? 'Saved fragments (.' : 'Transcript not found — saved fragments only (.') + ext + ')', 2400);
  }

  function exportConversation(ext, mime) {
    var turns = getConversation();
    // One message (a file on GitHub) or none: there is nothing to choose.
    if (!turns || turns.length < 2) { saveExport(turns, '', ext, mime); return; }
    openPicker(turns, ext, mime);
  }
  $('mdBtn').addEventListener('click', function () { exportConversation('md', 'text/markdown'); });
  $('txtBtn').addEventListener('click', function () { exportConversation('txt', 'text/plain'); });

  // ------------------------------------------------------------ dictation
  // One dictation at a time, and it always knows where the words are going.
  pad = $('pad');
  var padTextEl = $('padText');
  var PAD_KEY = 'assay.scratch.v1';
  var padBody = loadJSON(PAD_KEY, {}).text || '';
  var padSel = null;          // {start, end, scope} over padBody
  var voiceTarget = null;     // 'note' | 'pad' | 'padReplace'
  var noteBase = '';          // what the note held before this dictation began

  function savePad() { saveMap(PAD_KEY, { text: padBody, ts: Date.now() }); }

  function padAsk(msg) {
    $('padAskMsg').textContent = msg;
    $('padAsk').classList.add('show');
  }
  function padAskHide() { $('padAsk').classList.remove('show'); }

  // The only way dictation starts, and the only place a refusal is explained.
  // There is nothing to offer to install, so a no is a no.
  function dictate(target) {
    withVoice(function () { beginDictation(target); }, function (msg) {
      if (pad.classList.contains('show')) padAsk(msg, false);
      else toast(msg, 5000);
    });
  }
  $('padAskNo').addEventListener('click', padAskHide);

  function paintDictating(on) {
    $('noteMic').classList.toggle('on', on && voiceTarget === 'note');
    $('noteInput').classList.toggle('tall', on && voiceTarget === 'note');
    var pr = $('padRec');
    pr.classList.toggle('on', on && voiceTarget !== 'note');
    $('padRecLabel').textContent = (on && voiceTarget !== 'note') ? 'Stop' : 'Dictate';
  }

  function beginDictation(target) {
    voiceTarget = target;
    if (target === 'note') {
      noteBase = $('noteInput').value;
      if (noteBase && !/\s$/.test(noteBase)) noteBase += ' ';
    }
    paintDictating(true);
    startListening({
      interim: function (text) {
        if (voiceTarget === 'note') {
          $('noteInput').value = noteBase + text;
          growNote();
        } else {
          renderPad(text);
        }
      },
      final: function (text) {
        var t = text.replace(/^\s+/, '');
        if (!t) return;
        if (voiceTarget === 'note') {
          noteBase = noteBase + t + ' ';
          $('noteInput').value = noteBase;
          growNote();
          return;
        }
        if (voiceTarget === 'padReplace' && padSel) {
          padBody = padBody.slice(0, padSel.start) + t + padBody.slice(padSel.end);
          padSel = { start: padSel.start, end: padSel.start + t.length, scope: 'word' };
          voiceTarget = 'pad';          // the replacement is done; keep going as normal
        } else {
          padBody = padBody + (padBody && !/\s$/.test(padBody) ? ' ' : '') + t;
        }
        savePad();
        renderPad('');
      },
      error: function (msg) {
        paintDictating(false);
        voiceTarget = null;
        toast(msg, 3600);
      },
      end: function () { paintDictating(false); voiceTarget = null; }
    });
  }
  function endDictation() {
    stopListening();
    paintDictating(false);
    voiceTarget = null;
  }
  function growNote() {
    var el = $('noteInput');
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, Math.round(window.innerHeight * 0.38)) + 'px';
    el.scrollTop = el.scrollHeight;
  }
  $('noteInput').addEventListener('input', growNote);
  $('noteMic').addEventListener('click', function () {
    if (listening() && voiceTarget === 'note') return endDictation();
    dictate('note');
  });
  $('padRec').addEventListener('click', function () {
    if (listening() && voiceTarget !== 'note') return endDictation();
    dictate('pad');
  });

  // ---- the scratchpad
  // Rendered from the string every time, so an offset means the same thing
  // before and after a selection is painted into it.
  // The scratchpad is a text field, not a rendering of one. That is the whole
  // point of bringing your own voice: the keyboard's microphone types here like
  // any other keyboard, and so does your thumb. Everything Assay adds sits on
  // top of an ordinary textarea rather than replacing it.
  function renderPad(interim) {
    var text = padBody + (interim ? (padBody && !/\s$/.test(padBody) ? ' ' : '') + interim : '');
    if (padTextEl.value !== text) padTextEl.value = text;
    if (interim) padTextEl.scrollTop = padTextEl.scrollHeight;
    paintPadBar();
  }
  function paintPadBar() {
    $('padBar').classList.toggle('show', !!padSel);
    $('padSend').innerHTML = IS_GITHUB ? '&#x29C9; Copy notes' : '&#x2197; To composer';
    $('padSend').disabled = !padBody;
    $('padReword').style.display = voiceCtor() ? '' : 'none';
  }
  // Typing is the source of truth; dictation is just another way of typing.
  padTextEl.addEventListener('input', function () {
    padBody = padTextEl.value;
    padSel = null;
    savePad();
    paintPadBar();
  });

  // The paragraph an offset falls in, as plain string bounds — there are no
  // elements to walk inside a textarea.
  function padPara(off) {
    var text = padBody, from = 0, i;
    var parts = text.split(/\n{2,}/);
    for (i = 0; i < parts.length; i++) {
      var end = from + parts[i].length;
      if (off <= end || i === parts.length - 1) return { start: from, end: end, text: parts[i] };
      from = end + 2;
    }
    return { start: 0, end: text.length, text: text };
  }
  function padSelect(sel) {
    padSel = sel;
    if (sel) {
      try {
        padTextEl.setSelectionRange(sel.start, sel.end);
        padTextEl.focus();
      } catch (e) {}
    }
    paintPadBar();
  }
  // Tap a word, tap again for the sentence, again for the paragraph, again for
  // nothing — the same cycle as the page, driven by where the caret landed.
  function padCycle() {
    if (!padBody) return;
    var a = padTextEl.selectionStart, b = padTextEl.selectionEnd;
    if (a == null) return;
    var inside = padSel && a >= padSel.start && b <= padSel.end && (b - a) === (padSel.end - padSel.start);
    var para = padPara(a);
    var rel = a - para.start;
    if (!inside) {
      var words = segmentWords(para.text);
      var w = wordAt(words, rel);
      return padSelect(w ? { start: para.start + w.start, end: para.start + w.end, scope: 'word' } : null);
    }
    if (padSel.scope === 'word') {
      var sents = segmentSentences(para.text);
      var sb = sentenceBounds(sents, padSel.start - para.start, padSel.end - para.start);
      return padSelect(sb ? { start: para.start + sb.start, end: para.start + sb.end, scope: 'sentence' } : null);
    }
    if (padSel.scope === 'sentence') {
      return padSelect({ start: para.start, end: para.end, scope: 'paragraph' });
    }
    padSelect(null);
  }
  padTextEl.addEventListener('click', function () { setTimeout(padCycle, 0); });
  // A selection you dragged out yourself is a selection, and the bar should
  // offer to do something with it.
  padTextEl.addEventListener('select', function () {
    var a = padTextEl.selectionStart, b = padTextEl.selectionEnd;
    if (b > a && !(padSel && padSel.start === a && padSel.end === b)) {
      padSel = { start: a, end: b, scope: 'word' };
      paintPadBar();
    }
  });

  $('padReword').addEventListener('click', function () {
    if (!padSel) return;
    dictate('padReplace');
  });
  $('padCut').addEventListener('click', function () {
    if (!padSel) return;
    var at = padSel.start;
    padBody = (padBody.slice(0, padSel.start) + padBody.slice(padSel.end)).replace(/[ \t]{2,}/g, ' ');
    padSel = null;
    savePad();
    renderPad('');
    try { padTextEl.setSelectionRange(at, at); padTextEl.focus(); } catch (e) {}
  });
  $('padPick').addEventListener('click', function () {
    if (!padSel) return;
    var t = padBody.slice(padSel.start, padSel.end).trim();
    if (t.length < MIN_SEL_LEN) { toast('Too short to collect'); return; }
    addFragment(t);
    toast('Collected');
  });
  $('padCopy').addEventListener('click', function () {
    if (!padBody) return;
    copyText(padBody).then(function (ok) { toast(ok ? 'Copied' : 'Could not copy'); });
  });
  $('padClear').addEventListener('click', function () {
    if (!padBody) return;
    padBody = '';
    padSel = null;
    savePad();
    renderPad('');
    toast('Scratchpad cleared');
  });
  // Insertion: the words go where you were going to type them.
  $('padSend').addEventListener('click', function () {
    var text = padSel ? padBody.slice(padSel.start, padSel.end).trim() : padBody.trim();
    if (!text) return;
    if (IS_GITHUB) {
      copyText(text).then(function (ok) { toast(ok ? 'Copied' : 'Could not copy'); });
      return;
    }
    if (insertIntoComposer(text)) {
      closePad();
      toast(padSel ? 'Put in the message box' : 'Scratchpad put in the message box', 2400);
    } else {
      copyText(text).then(function (ok) { toast(ok ? 'No message box here — copied instead' : 'Could not copy', 3000); });
    }
  });

  function openPad() {
    hideChip();
    clearPending();
    closeSheet();
    padSel = null;
    padBody = loadJSON(PAD_KEY, {}).text || padBody;
    pad.classList.add('show');
    padAskHide();
    paintDictating(listening());
    renderPad('');
    updatePill();
  }
  function closePad() {
    endDictation();
    padAskHide();
    pad.classList.remove('show');
    updatePill();
  }
  $('padBtn').addEventListener('click', openPad);
  $('padClose').addEventListener('click', function () { closePad(); openSheet(); });

  // ------------------------------------------------------------- composing
  function findComposer() {
    return document.querySelector('#prompt-textarea') ||
      document.querySelector('div[contenteditable="true"].ProseMirror') ||
      document.querySelector('form div[contenteditable="true"]') ||
      document.querySelector('div[contenteditable="true"]') ||
      document.querySelector('form textarea') ||
      document.querySelector('main textarea');
  }

  // The payload landed but structure did too? Check the first and last
  // meaningful lines are present — a run-on paste passes a naive check.
  function composerHas(el, text) {
    var hay = ((el.tagName === 'TEXTAREA' ? el.value : el.innerText) || '');
    var lines = text.split('\n').filter(function (l) { return l.trim(); });
    if (!lines.length) return false;
    var first = lines[0].slice(0, 20);
    var last = lines[lines.length - 1].slice(0, 20);
    return hay.indexOf(first) !== -1 && hay.indexOf(last) !== -1;
  }

  function insertIntoComposer(text) {
    var el = findComposer();
    if (!el) return false;
    try {
      el.focus();
      if (el.tagName === 'TEXTAREA') {
        var proto = window.HTMLTextAreaElement.prototype;
        var setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
        setter.call(el, el.value ? el.value + '\n\n' + text : text);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        return composerHas(el, text);
      }
      // contenteditable (ProseMirror on both ChatGPT and Claude).
      var sel = window.getSelection();
      sel.selectAllChildren(el);
      sel.collapseToEnd();
      // Structured insertion keeps the payload human-readable: a paragraph
      // break between fragments, a line break within one. A single
      // insertText with embedded newlines flattens to a run-on in
      // ProseMirror, which is exactly the bug this avoids.
      try {
        text.split('\n\n').forEach(function (para, i) {
          if (i > 0) {
            var ok = false;
            try { ok = document.execCommand('insertParagraph'); } catch (e2) {}
            if (!ok) {
              document.execCommand('insertLineBreak');
              document.execCommand('insertLineBreak');
            }
          }
          para.split('\n').forEach(function (line, j) {
            if (j > 0) document.execCommand('insertLineBreak');
            if (line) document.execCommand('insertText', false, line);
          });
        });
      } catch (e) {}
      if (composerHas(el, text)) return true;
      // Fallback: a synthetic paste, which some editors handle natively.
      try {
        var dt = new DataTransfer();
        dt.setData('text/plain', text);
        el.dispatchEvent(new ClipboardEvent('paste', {
          clipboardData: dt, bubbles: true, cancelable: true
        }));
      } catch (e) {}
      return composerHas(el, text);
    } catch (e) {
      return false;
    }
  }

  function legacyCopy(t) {
    var ta = document.createElement('textarea');
    ta.value = t;
    ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;';
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) {}
    ta.remove();
    return ok;
  }

  function copyText(t) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(t).then(
        function () { return true; },
        function () { return legacyCopy(t); }
      );
    }
    return Promise.resolve(legacyCopy(t));
  }

  function finishBatch(msg) {
    saveBackup();
    fragments = [];
    marks = [];
    persist(); updatePill(); closeSheet(); redraw();
    toast(msg, 2600);
  }

  function manualCopy(payload) {
    manualEl.classList.add('show');
    $('manualTxt').value = payload;
    $('manualTxt').select();
    toast('Copy the text below manually', 2600);
  }

  $('goBtn').addEventListener('click', function () {
    if (!fragments.length) return;
    var payload = buildPayload();
    if (IS_GITHUB) {
      // Keep the fragments: what you paste them into is somewhere else, and a
      // clipboard write can fail quietly on a phone.
      copyText(payload).then(function (copied) {
        if (copied) toast('Copied ' + fragments.length + ' fragment' + (fragments.length > 1 ? 's' : ''), 2400);
        else manualCopy(payload);
      });
      return;
    }
    if (insertIntoComposer(payload)) {
      finishBatch('In the composer — review and send');
      return;
    }
    copyText(payload).then(function (copied) {
      if (copied) {
        finishBatch('Copied — paste into the composer');
      } else {
        manualCopy(payload); // last resort, keeping the fragments
      }
    });
  });

  // The thread memory this used to keep is gone; clear what it left behind.
  try { localStorage.removeItem('assay.convoLog.v1'); } catch (e) {}
  paintFlatBtn();
  updatePill();
  syncViewport();
  // A grant puts the script in the manager's sandbox, where `window` is not the
  // page's. Everything here works either way, but the page-side handle is worth
  // keeping: it is what a second run toggles, and what a console reaches.
  function publish(api) {
    window.__assay = api;
    try {
      if (typeof unsafeWindow !== 'undefined' && unsafeWindow && unsafeWindow !== window) {
        unsafeWindow.__assay = api;
      }
    } catch (e) {}   // Firefox may refuse to hand a sandbox object to the page
  }
  publish({
    toggle: toggleSheet,
    version: VERSION,
    // What each strategy sees on this page, and if none of them sees anything,
    // enough of the page's shape to say why. A selector that has been renamed
    // empties an export silently; this is how that stops being a guess.
    _find: function () {
      var out = {
        strategies: [], structural: 0, found: 0, sample: [],
        walk: lastWalk ? {
          passes: lastWalk.passes, stopped: lastWalk.stopped, dialogs: lastWalk.dialogs,
          top: lastWalk.top.slice(-6), windows: lastWalk.windows.length,
          first3: lastWalk.windows.slice(0, 3), last2: lastWalk.windows.slice(-2),
          final: lastWalk.final
        } : null,
        runtime: IN_EXTENSION ? 'extension' : 'userscript/page',
        voice: {
          ctor: !!voiceCtor(),
          onDeviceApi: !!(voiceCtor() && voiceCtor().available),
          lang: voiceLang()
        }
      };
      CHAT_FINDERS.forEach(function (f) {
        var n = 0;
        try { n = f.find ? f.find().length : document.querySelectorAll(f.sel).length; } catch (e) { n = -1; }
        out.strategies.push({ sel: f.sel, n: n });
      });
      try { out.structural = structuralTurns().length; } catch (e) {}
      var live = liveTurns();
      out.found = live.length;
      out.roles = live.slice(0, 6).map(function (t) { return t.role; });
      out.heads = live.slice(0, 3).map(function (t) { return t.head; });
      var named = out.strategies.some(function (st) { return st.n > 0; });
      {
        // Nothing found by name: describe what the page actually has, so the
        // next version can be aimed rather than guessed. Counts of the marks a
        // thread has carried at one time or another, the hidden labels, the
        // testids, and the wrappers around the first label and the first
        // markdown block.
        out.census = {};
        ['article', '[data-turn]', '[data-turn-id]', '[data-message-id]', '[data-message-author-role]',
         '[class*="markdown"]', '[class*="prose"]', 'main', '[role="presentation"]', '[data-testid]'].forEach(function (q) {
          try { out.census[q] = document.querySelectorAll(q).length; } catch (e) { out.census[q] = -1; }
        });
        try {
          out.census.labels = saidHeadings().slice(0, 8).map(function (h) { return h.tagName.toLowerCase() + ':' + normText(h.textContent); });
          var tids = {}, te = document.querySelectorAll('[data-testid]');
          for (var ti = 0; ti < te.length; ti++) {
            var tv = te[ti].getAttribute('data-testid').replace(/\d+/g, 'N');
            tids[tv] = (tids[tv] || 0) + 1;
          }
          out.census.testids = Object.keys(tids).sort(function (a, b) { return tids[b] - tids[a]; }).slice(0, 14)
            .map(function (k) { return k + '×' + tids[k]; });
          function pathOf(el) {
            var parts = [], n = 0;
            while (el && el !== document.body && n++ < 7) {
              var cls = ((el.className && el.className.indexOf ? el.className : '') + '').split(/\s+/)
                .filter(function (c) { return c && !/^(flex|grid|text-|bg-|p[xytrbl]?-|m[xytrbl]?-|w-|h-|gap-|rounded|border|absolute|relative|overflow|max-|min-|items-|justify-|@)/.test(c); })
                .slice(0, 3).join('.');
              var attrs = [];
              for (var a = 0; a < el.attributes.length; a++) {
                var nm = el.attributes[a].name;
                if (/^data-/.test(nm)) attrs.push(nm + '=' + el.attributes[a].value.slice(0, 18));
              }
              parts.push(el.tagName.toLowerCase() + (cls ? '.' + cls : '') + (attrs.length ? '[' + attrs.join('][') + ']' : '') +
                '{' + (el.textContent || '').trim().length + '}');
              el = el.parentElement;
            }
            return parts.join(' < ');
          }
          // The first label of each side, where the finder put its turn, and
          // how much text that turn holds — the one thing a paste has to say
          // when the label finder is the one that answered.
          var hs = saidHeadings(), shown = {};
          out.census.labelTurns = [];
          for (var li = 0; li < hs.length && out.census.labelTurns.length < 2; li++) {
            var side = /^you\b/i.test(normText(hs[li].textContent)) ? 'you' : 'them';
            if (shown[side]) continue;
            shown[side] = true;
            var tn = turnOfLabel(hs[li], hs[li - 1], hs[li + 1]);
            out.census.labelTurns.push({ label: pathOf(hs[li]), turn: tn ? pathOf(tn) : 'none' });
          }
          var md = document.querySelector('main [class*="markdown"], [class*="markdown"]');
          if (md) out.census.markdownPath = pathOf(md);
        } catch (e) { out.census.err = e.message; }
        var root = (!live.length || !named) ? (document.querySelector('main') || document.body) : null;
        var seen = {}, all = root ? root.querySelectorAll('*') : [];
        for (var i = 0; i < all.length && i < 4000; i++) {
          var el = all[i];
          if (host.contains(el)) continue;
          if ((el.textContent || '').trim().length < 80) continue;
          var cls = ((el.className && el.className.indexOf ? el.className : '') + '').split(/\s+/)
            .filter(function (c) { return c && !/^(flex|grid|text-|bg-|p[xytrbl]?-|m[xytrbl]?-|w-|h-|gap-|rounded|border|absolute|relative|overflow)/.test(c); })
            .slice(0, 4).join('.');
          var attrs = [];
          for (var a = 0; a < el.attributes.length; a++) {
            var nm = el.attributes[a].name;
            if (/^data-/.test(nm)) attrs.push(nm + '=' + el.attributes[a].value.slice(0, 24));
          }
          var k = el.tagName.toLowerCase() + (cls ? '.' + cls : '') + (attrs.length ? '[' + attrs.join('][') + ']' : '');
          if (!seen[k]) { seen[k] = true; out.sample.push(k); }
          if (out.sample.length >= 25) break;
        }
      }
      return out;
    },
    // Every editable on the page and what Assay decided it is. A composer we
    // treat as conversation is a chat you cannot type in, so this is the one
    // question worth being able to answer without the page in front of you.
    _editables: function () {
      var out = [];
      var eds = document.querySelectorAll(EDITABLE_SEL);
      for (var i = 0; i < eds.length && i < 20; i++) {
        var ed = eds[i];
        if (ed === host || host.contains(ed)) continue;
        var cls = ((ed.className && ed.className.indexOf ? ed.className : '') + '').slice(0, 40);
        out.push({
          tag: ed.tagName.toLowerCase(),
          id: ed.id || '',
          testid: (ed.getAttribute('data-testid') || ''),
          cls: cls,
          composer: isComposerEl(ed),
          inConversation: (function () { try { return inConversation(ed); } catch (e) { return 'err'; } })(),
          selectable: !!pageEditable(ed),
          text: ((ed.value != null ? ed.value : ed.textContent) || '').trim().slice(0, 40)
        });
      }
      return out;
    },
    _harvest: function (onProgress) { harvestStop = false; return harvest(onProgress || function () {}); },
    _debug: function () {
      return {
        pending: pending ? { start: pending.start, end: pending.end, scope: pending.scope, text: pendingText() } : null,
        fragments: fragments.map(function (f) { return { text: f.text, note: f.note, notePos: f.notePos, verb: f.verb, colorIdx: f.colorIdx }; }),
        marks: marks.length,
        highlights: paintedCount(),
        exportMd: buildConversationMarkdown(getConversation()),
        exportTxt: buildConversationText(getConversation())
      };
    }
  });
})();
